# -*- coding: utf-8 -*-
"""
Created on Wed Dec  3 17:11:27 2025

@author: ti-15
"""
import json
import csv

"""
On définit la fonction date_fr nous permettant de transformer la date anglais
en date française par le biai de split et d'une varaibale appelée "partie" pour
placer dans l'ordre souhaité le jour le mois et année.
"""

def date_fr(date_debut):
    partie = date_debut.split("-")
    annee = partie[0]
    mois = partie[1]
    jour = partie[2]
    return jour + "/" + mois + "/" + annee

"""
Dans le cas où le fichier json est introuvable, on démarre avec un try/except
pour éviter de faire planter la console.
"""

try:
    f = open("concentrations-polluants.json", "r", encoding="utf-8")
    donnees = json.load(f)
except FileNotFoundError:
    print("Le Fichier json n'a pas été trouvé!")
finally:
    f.close()
   

"""
Nous allons créer un fichier excel grâce au "w", l'encoding "utf-8-sig permet d'avoir les 
accents et caractères spéciaux tandis que newline nous permet d'empêcher des
lignes vides dans notre csv.La variable ecritCSV nous autorise à créer des
dictionnaires dans notre fichier csv.
"""

fichier = open("polluant_poitiers.csv", "w", encoding="utf-8-sig", newline="")
colonnes = ["Nom_Station", "Latitude", "Longitude", "Date De Prelevement", "Nom_Polluant", "Valeur", "Unité"]
ecritCSV = csv.DictWriter(fichier, delimiter=";", fieldnames=colonnes, quoting=csv.QUOTE_ALL)
ecritCSV.writeheader()


"""
"if not all" nous permet de vérifier si chaque élément de infos est renseigné ou
non, si ce n'est pas le cas "continue" veut dire que nous n'écrions pas cette
ligne et passons à la suivante pour un i nombre de fois de notre boucle for.
"""
for i in donnees : 
       F = i["fields"]

       infos = ["nom_station", "nom_poll", "valeur", "unite", "date_debut", "x_wgs84", "y_wgs84"]
       if not all(unElement in F for unElement in infos):
           continue
            
        
       unite = F["unite"]
       if unite == "ug.m-3":
           unite = "µg/m³"
       elif unite == "mg.m-3":
           unite = "mg/m³"
           
       ecritCSV.writerow({
           "Nom_Station": F["nom_station"],
           "Latitude": F["y_wgs84"],
           "Longitude": F["x_wgs84"],
           "Date De Prelevement": date_fr(F["date_debut"]),
           "Nom_Polluant": F["nom_poll"],
           "Valeur": F["valeur"],
           "Unité": unite})
       
fichier.close()

print("Le fichier a bien été crée !")
   
    
"""
l.63-67 Nous changeons nos unités comme demandé puisque "µ" n'existait pas dans
 notre fichier json grâce à notre if.
"""
             
           
"""
l.69-80 Cette dernière partie est tout simplement l'écriture de notre ligne complète
dans notre nouveau fichier csv (F étant le dictionnaire dans lequel nous allons chercher
notre contenu) ; nous retrouvons également notre fonction date_fr définie au début.
Nous pouvons fermer le fichier et le retrouver sur Excel!
"""  
    
       
