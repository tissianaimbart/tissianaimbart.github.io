
# Notre objectif est d'estimer la valeur fonciere de logements a partir de leur surface réelle
# Pour cela, nous avons des transactions immobilieres depuis 2021 (appartements et maisons)
# dans le fichier train que nous allons importer pour entraîner et prédire nos prix

train      <- read.csv2('train.csv')
to_predict <- read.csv2('to_predict.csv')



# Ici, nous utilisons des fonctions qui vont nous permettre de gagner du temps et
# de ne pas être redondant dans notre code.

# Variance empirique de x pour calculer le coefficient directeur
var_x <- function(x) {
  return(mean(x^2) - mean(x)^2)
}

# Covariance empirique de x et y pour calculer le coefficient directeur
cov_xy <- function(x, y) {
  return(mean(x * y) - mean(x) * mean(y))
}

# Apres exploration, on distingue les 3 segments que l'on utilisera pour predire:
# 1. Maisons a Niort
# 2. Maisons hors Niort (marche immobilier different de Niort)
# 3. Tous les appartements (Niort + hors Niort fusionnes) car il n'y a pas assez d'appartements hors niort pour le segmenter seuls
# On filtre egalement les valeurs manquantes ou nulles

maisons_niort <- train[train$Commune == "NIORT" &
                       train$Type.local == "Maison" &
                       train$Surface.reelle.bati > 0 &
                       train$Valeur.fonciere > 0, ]

maisons_hors_niort <- train[train$Commune != "NIORT" &
                            train$Type.local == "Maison" &
                            train$Surface.reelle.bati > 0 &
                            train$Valeur.fonciere > 0, ]

appartements <- train[train$Type.local == "Appartement" &
                      train$Surface.reelle.bati > 0 &
                      train$Valeur.fonciere > 0, ]



# Modele 1 - Maisons a Niort : prix et surface reelle
# Pour le modele des maisons à Niort, on utilise un modèle puissance de la forme
# Prix = a * racine carre de la surface + b

x <- sqrt(maisons_niort$Surface.reelle.bati)
y <- maisons_niort$Valeur.fonciere

# On estime les coefficients par la methode des moindres carres
a_maisonniort <- cov_xy(x, y) / var_x(x)
b_maisonniort <- mean(y) - a_maisonniort * mean(x)

# Et on calcule les prix predits et les residus sur le jeu d'entrainement
maisons_niort$PrixPredits <- a_maisonniort * sqrt(maisons_niort$Surface.reelle.bati) + b_maisonniort
maisons_niort$Residus     <- maisons_niort$Valeur.fonciere - maisons_niort$PrixPredits
SCR_maisonniort <- sum(maisons_niort$Residus^2)



# Modele 2 - Maisons hors Niort 
# Meme type de modele que pour Niort, mais les coefficients different
# car le marche immobilier hors Niort a un niveau de prix different

x <- sqrt(maisons_hors_niort$Surface.reelle.bati)
y <- maisons_hors_niort$Valeur.fonciere

a_maisonhorsniort <- cov_xy(x, y) / var_x(x)
b_maisonhorsniort <- mean(y) - a_maisonhorsniort * mean(x)

maisons_hors_niort$PrixPredits <- a_maisonhorsniort * sqrt(maisons_hors_niort$Surface.reelle.bati) + b_maisonhorsniort
maisons_hors_niort$Residus     <- maisons_hors_niort$Valeur.fonciere - maisons_hors_niort$PrixPredits
SCR_maisonhorsniort <- sum(maisons_hors_niort$Residus^2)



# Modele 3 - Appartements:

# On passe au logarithme pour lineariser la relation
# Nous avons donc un modele puissance : Prix = exp(b) * Surface^a
# On estime donc a et b, puis on revient
# a l'echelle originale avec exp() pour obtenir les prix predits

x <- log(appartements$Surface.reelle.bati)
y <- log(appartements$Valeur.fonciere)

a_app <- cov_xy(x, y) / var_x(x)
b_app <- mean(y) - a_app * mean(x)

# Retour a l'echelle originale avec l'exponentiel
appartements$PrixPredits <- exp(a_app * log(appartements$Surface.reelle.bati) + b_app)
appartements$Residus     <- appartements$Valeur.fonciere - appartements$PrixPredits
SCR_app <- sum(appartements$Residus^2)

# Maintenant que nos tests et modeles sont realises, On applique le modele correspondant
# a chaque logement selon son type de local et sa commune, en utilisant les 
# coefficients estimes sur le jeu d'entrainement

predictions <- numeric(nrow(to_predict))

for (i in 1:nrow(to_predict)) {
  commune <- to_predict$Commune[i]
  type    <- to_predict$Type.local[i]
  surface <- as.numeric(to_predict$Surface.reelle.bati[i])

  # Si la surface est manquante ou invalide, on ne peut pas predire et on passe
  if (is.na(surface) || surface <= 0) {
    predictions[i] <- NA
    next
  }

  if (type == "Maison" & commune == "NIORT") {
    predictions[i] <- a_maisonniort * sqrt(surface) + b_maisonniort

  } else if (type == "Maison" & commune != "NIORT") {
    predictions[i] <- a_maisonhorsniort * sqrt(surface) + b_maisonhorsniort

  } else if (type == "Appartement") {
    predictions[i] <- exp(a_app * log(surface) + b_app)
  }
}

# On arrondi à l'euro pres pour rester comprehensible à l'acheteur
to_predict$Valeur.fonciere <- round(predictions, 0)


# Et pour finir on exporte notre fichier comme prevu, en ne gardant que 
# les colonnes id et valeur fonciere.

write.csv2(
  to_predict[, c("id", "Valeur.fonciere")],
  "prediction.csv",
  row.names = FALSE)

