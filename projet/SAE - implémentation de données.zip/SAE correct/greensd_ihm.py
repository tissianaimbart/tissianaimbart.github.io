# -*- coding: utf-8 -*-
"""
Created on Thu Apr  2 14:02:11 2026

@author: strachi
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Mar 30 23:08:36 2026

@author: salma
"""


import tkinter as tk
from tkinter import ttk, messagebox, filedialog, scrolledtext
import mysql.connector
import csv
import os
import re
from datetime import datetime

# ─────────────────────────────────────────────────────
#  CONFIG CONNEXION  (EasyPHP / PhpMyAdmin)
# ─────────────────────────────────────────────────────
DB_CONFIG = {
    "host":     "localhost",
    "port":     3306,
    "user":     "root",
    "password": "",
    "database": "greensd-tdb",   # ← greensd-tdb si besoin
}

# ─────────────────────────────────────────────────────
#  THÈME
# ─────────────────────────────────────────────────────
C_BG      = "#1A2332"
C_PANEL   = "#1F2D3D"
C_SIDEBAR = "#151E2B"
C_ACCENT  = "#6FA4AF"
C_GREEN2  = "#9CAB84"
C_BLUE    = "#555879"
C_ORANGE  = "#659287"
C_RED     = "#FF5252"
C_PURPLE  = "#AEC6F2"
C_TEXT    = "#E8EDF2"
C_DIM     = "#819A91"
C_HDR_BG  = "#0F3D2E"
C_ROW_A   = "#1C2D3E"
C_ROW_B   = "#213040"

FONT_H1   = ("Segoe UI", 17, "bold")
FONT_H2   = ("Segoe UI", 12, "bold")
FONT_BODY = ("Segoe UI", 10)
FONT_SM   = ("Segoe UI", 9)
FONT_CODE = ("Consolas", 10)

# ─────────────────────────────────────────────────────
#  UTILITAIRES DB
# ─────────────────────────────────────────────────────
def get_conn():
    return mysql.connector.connect(**DB_CONFIG)

def get_tables():
    try:
        c = get_conn(); cur = c.cursor()
        cur.execute("SHOW TABLES")
        t = [r[0] for r in cur.fetchall()]
        c.close(); return t
    except Exception as e:
        messagebox.showerror("Connexion", str(e)); return []

def run_sql(sql, params=None, fetch=True):
    c = get_conn(); cur = c.cursor()
    cur.execute(sql, params or ())
    if fetch:
        cols = [d[0] for d in (cur.description or [])]
        rows = cur.fetchall(); c.close()
        return cols, rows
    else:
        c.commit(); nb = cur.rowcount; c.close()
        return nb

# ─────────────────────────────────────────────────────
#  WIDGETS COMMUNS
# ─────────────────────────────────────────────────────
def btn(parent, text, cmd, color=None, **kw):
    color = color or C_ACCENT
    b = tk.Button(parent, text=text, command=cmd, bg=color, fg="white",
                  relief="flat", font=FONT_BODY, cursor="hand2",
                  padx=12, pady=5, bd=0,
                  activebackground=C_GREEN2, activeforeground="white", **kw)
    b.bind("<Enter>", lambda e, c=color: b.config(bg=_lighten(c)))
    b.bind("<Leave>", lambda e, c=color: b.config(bg=c))
    return b

def _lighten(hex_color):
    try:
        h = hex_color.lstrip("#")
        r,g,bv = int(h[0:2],16), int(h[2:4],16), int(h[4:6],16)
        r,g,bv = min(255,r+30), min(255,g+30), min(255,bv+30)
        return f"#{r:02x}{g:02x}{bv:02x}"
    except:
        return hex_color

def make_tree(parent, cols):
    s = ttk.Style(); s.theme_use("clam")
    s.configure("G.Treeview",
        background=C_ROW_B, foreground=C_TEXT,
        fieldbackground=C_ROW_B, rowheight=25, font=FONT_BODY)
    s.configure("G.Treeview.Heading",
        background=C_HDR_BG, foreground=C_ACCENT,
        font=FONT_H2, relief="flat")
    s.map("G.Treeview", background=[("selected", C_ACCENT)],
          foreground=[("selected", "#000")])
    wrap = tk.Frame(parent, bg=C_BG)
    wrap.pack(fill="both", expand=True)
    sy = ttk.Scrollbar(wrap, orient="vertical")
    sx = ttk.Scrollbar(wrap, orient="horizontal")
    tree = ttk.Treeview(wrap, columns=cols, show="headings",
                        style="G.Treeview",
                        yscrollcommand=sy.set, xscrollcommand=sx.set)
    sy.config(command=tree.yview); sx.config(command=tree.xview)
    for col in cols:
        tree.heading(col, text=col)
        tree.column(col, width=max(100, len(col)*10), anchor="center", minwidth=60)
    sy.pack(side="right", fill="y")
    sx.pack(side="bottom", fill="x")
    tree.pack(fill="both", expand=True)
    tree.tag_configure("a", background=C_ROW_A)
    tree.tag_configure("b", background=C_ROW_B)
    return tree

def fill_tree(tree, rows):
    tree.delete(*tree.get_children())
    for i, r in enumerate(rows):
        tree.insert("", "end",
                    values=[str(v) if v is not None else "" for v in r],
                    tags=("a" if i%2==0 else "b",))

def section(parent, title):
    return tk.LabelFrame(parent, text=f"  {title}  ",
                         bg=C_BG, fg=C_ACCENT, font=FONT_H2,
                         bd=1, relief="groove", labelanchor="nw")

def entry_row(parent, label_text, var, row, col=0, width=28, show=""):
    tk.Label(parent, text=label_text, bg=C_BG, fg=C_DIM,
             font=FONT_SM, anchor="e", width=18).grid(
                 row=row, column=col, padx=(6,2), pady=4, sticky="e")
    e = tk.Entry(parent, textvariable=var, bg=C_PANEL, fg=C_TEXT,
                 font=FONT_BODY, insertbackground=C_TEXT,
                 relief="flat", width=width, show=show)
    e.grid(row=row, column=col+1, padx=(2,6), pady=4, sticky="w")
    return e

# ════════════════════════════════════════════════════
#  PAGE ACCUEIL
# ════════════════════════════════════════════════════
class PageAccueil(tk.Frame):
    def __init__(self, parent, ctrl):
        super().__init__(parent, bg=C_BG)
        self.ctrl = ctrl
        hero = tk.Frame(self, bg=C_BG)
        hero.pack(pady=(50, 10))
        tk.Label(hero, text="🌿", font=("Segoe UI", 48), bg=C_BG, fg=C_ACCENT).pack()
        tk.Label(hero, text="GreenSD", font=("Segoe UI", 36, "bold"),
                 bg=C_BG, fg=C_ACCENT).pack()
        tk.Label(hero, text="Système de gestion logistique bas‑carbone",
                 font=("Segoe UI", 12), bg=C_BG, fg=C_DIM).pack(pady=4)
        self.status = tk.Label(self, text="", font=FONT_SM, bg=C_BG)
        self.status.pack(pady=(4, 24))
        self._ping()
        cards_data = [
            ("📋", "Tables",      "Consulter\nles tables",       "PageTables",   C_ACCENT),
            ("📦", "Gestion",        "Ajouter / modifier\n/ supprimer", "PageGestion",  C_BLUE),
            ("📂", "Import CSV",  "Importer les\nfichiers ", "PageImport",   C_ORANGE),
            ("🔍", "Requêtes",    "Insérer des requêtes sql",     "PageRequetes", C_PURPLE),
            ("💨", "CO₂",        "Tableau de bord\némissions",   "PageCO2",      C_GREEN2),
            ("⚙️", "Connexion",   "Paramètres\nMySQL",           "PageSettings", C_DIM),
        ]
        grid = tk.Frame(self, bg=C_BG)
        grid.pack()
        for i, (icon, title, sub, page, color) in enumerate(cards_data):
            c = tk.Frame(grid, bg=color, width=170, height=110, cursor="hand2")
            c.grid(row=i//3, column=i%3, padx=10, pady=10)
            c.pack_propagate(False)
            c.bind("<Button-1>", lambda e, p=page: ctrl.show(p))
            tk.Label(c, text=icon, font=("Segoe UI", 24), bg=color, fg="white").pack(pady=(10,0))
            tk.Label(c, text=title, font=("Segoe UI", 11, "bold"), bg=color, fg="white").pack()
            tk.Label(c, text=sub, font=("Segoe UI", 8), bg=color, fg="white").pack()
            for w in c.winfo_children():
                w.bind("<Button-1>", lambda e, p=page: ctrl.show(p))

    def _ping(self):
        try:
            c = get_conn(); c.close()
            self.status.config(
                text=f"✅  Connecté  ·  {DB_CONFIG['database']}  @  {DB_CONFIG['host']}:{DB_CONFIG['port']}",
                fg=C_ACCENT)
        except Exception as e:
            self.status.config(text=f"❌  {e}", fg=C_RED)

# ════════════════════════════════════════════════════
#  PAGE TABLES
# ════════════════════════════════════════════════════
class PageTables(tk.Frame):
    def __init__(self, parent, ctrl):
        super().__init__(parent, bg=C_BG)
        self.ctrl = ctrl
        self._tree = None
        self._all_rows = []
        self._cols = []
        top = tk.Frame(self, bg=C_PANEL, pady=8)
        top.pack(fill="x")
        tk.Label(top, text="📋  Visualisation des tables",
                 font=FONT_H1, bg=C_PANEL, fg=C_TEXT).pack(side="left", padx=16)
        btn(top, "🔄", self._reload_tables, color="#333").pack(side="right", padx=6)
        btn(top, "◀ Accueil", lambda: ctrl.show("PageAccueil"), color="#444").pack(side="right", padx=4)
        body = tk.Frame(self, bg=C_BG)
        body.pack(fill="both", expand=True)
        side = tk.Frame(body, bg=C_SIDEBAR, width=175)
        side.pack(side="left", fill="y")
        side.pack_propagate(False)
        tk.Label(side, text="Tables", font=FONT_H2, bg=C_SIDEBAR, fg=C_ACCENT).pack(pady=10)
        self._lb = tk.Listbox(side, bg=C_SIDEBAR, fg=C_TEXT, font=FONT_BODY,
                              selectbackground=C_ACCENT, selectforeground="#000",
                              relief="flat", bd=0, activestyle="none")
        self._lb.pack(fill="both", expand=True, padx=6, pady=4)
        self._lb.bind("<<ListboxSelect>>", self._on_select)
        right = tk.Frame(body, bg=C_BG)
        right.pack(fill="both", expand=True)
        info_bar = tk.Frame(right, bg=C_BG)
        info_bar.pack(fill="x", padx=10, pady=(6,2))
        self._lbl_info = tk.Label(info_bar, text="← Sélectionne une table",
                                  bg=C_BG, fg=C_DIM, font=FONT_SM)
        self._lbl_info.pack(side="left")
        btn(info_bar, "⬇ Export CSV", self._export_csv, color=C_BLUE).pack(side="right", padx=10)
        tk.Label(info_bar, text="🔎", bg=C_BG, fg=C_DIM, font=FONT_SM).pack(side="right", padx=(0,4))
        self._var_filter = tk.StringVar()
        self._var_filter.trace("w", lambda *_: self._apply_filter())
        tk.Entry(info_bar, textvariable=self._var_filter, bg=C_PANEL, fg=C_TEXT,
                 font=FONT_BODY, insertbackground=C_TEXT, relief="flat",
                 width=25).pack(side="right", padx=4)
        tk.Label(info_bar, text="Filtre :", bg=C_BG, fg=C_DIM, font=FONT_SM).pack(side="right")
        self._tree_wrap = tk.Frame(right, bg=C_BG)
        self._tree_wrap.pack(fill="both", expand=True)
        self._reload_tables()

    def _reload_tables(self):
        self._lb.delete(0, "end")
        for t in get_tables():
            self._lb.insert("end", t)

    def _on_select(self, _=None):
        sel = self._lb.curselection()
        if not sel: return
        self._cur_table = self._lb.get(sel[0])
        try:
            self._cols, self._all_rows = run_sql(f"SELECT * FROM `{self._cur_table}`")
            self._lbl_info.config(
                text=f"  {self._cur_table}  ·  {len(self._all_rows)} ligne(s)  ·  {len(self._cols)} colonne(s)",
                fg=C_TEXT)
            self._refresh_tree(self._cols, self._all_rows)
        except Exception as e:
            messagebox.showerror("Erreur", str(e))

    def _apply_filter(self):
        if not self._all_rows: return
        q = self._var_filter.get().lower()
        filtered = [r for r in self._all_rows if any(q in str(v).lower() for v in r)]
        fill_tree(self._tree, filtered)

    def _refresh_tree(self, cols, rows):
        for w in self._tree_wrap.winfo_children(): w.destroy()
        self._tree = make_tree(self._tree_wrap, cols)
        fill_tree(self._tree, rows)

    def _export_csv(self):
        if not hasattr(self, "_cur_table"): return
        path = filedialog.asksaveasfilename(
            defaultextension=".csv",
            initialfile=f"{self._cur_table}_export.csv",
            filetypes=[("CSV", "*.csv")])
        if not path: return
        with open(path, "w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f, delimiter=";")
            w.writerow(self._cols)
            w.writerows(self._all_rows)
        messagebox.showinfo("Export", f"✅ Fichier exporté :\n{path}")

# ════════════════════════════════════════════════════
#  PAGE CRUD
# ════════════════════════════════════════════════════
TABLES_META = {
    "Partenaire": {
        "pk": "codePartenaire",
        "fields": [
            ("codePartenaire", "Code (auto)", "int"),
            ("nomPartenaire",  "Nom",         "str"),
            ("Ville",          "Ville",        "str"),
        ]
    },
    "vehicule": {
        "pk": "codeVehicule",
        "fields": [
            ("codeVehicule",   "Code (auto)",  "int"),
            ("typeVehicule",   "Type",         "choice",
             ["Velo-cargo", "Triporteur", "UtilitaireElectrique"]),
            ("nombreVehicule", "Nombre",       "int"),
            ("autonomie",      "Autonomie km", "int"),
            ("capacite",       "Capacité kg",  "int"),
        ]
    },
    "livreur": {
        "pk": "codeLivreur",
        "fields": [
            ("codeLivreur",    "Code (auto)",  "int"),
            ("nomLivreur",     "Nom",          "str"),
            ("PrenomLivreur",  "Prénom",       "str"),
            ("dateEmbauche",   "Date embauche (AAAA-MM-JJ)", "date"),
        ]
    },
    "Client": {
        "pk": "codeClient",
        "fields": [
            ("codeClient",     "Code (auto)",    "int"),
            ("nomClient",  "nomClient", "str"),
            ("RueClient",      "Rue",            "str"),
            ("CPClient",       "Code postal",    "str"),
            ("VilleClient",    "Ville",          "str"),
        ]
    },
    "tournee": {
        "pk": "codeTournee",
        "fields": [
            ("codeTournee",    "Code (auto)",            "int"),
            ("dateSortie",     "Date sortie (AAAA-MM-JJ)", "date"),
            ("codeLivreur",    "Code livreur",            "int"),
            ("codeVehicule",   "Code véhicule",           "int"),
        ]
    },
    "entree": {
        "pk": "codeEntree",
        "fields": [
            ("codeEntree",     "Code (auto)",              "int"),
            ("dateEntree",     "Date entrée (AAAA-MM-JJ)", "date"),
            ("quantiteColis",  "Qté colis",               "int"),
            ("codePartenaire", "Code partenaire",          "int"),
        ]
    },
    "Livraison": {
        "pk": "codeLivraison",
        "fields": [
            ("codeLivraison",  "Code (auto)",  "int"),
            ("poidsTotal",     "Poids total",  "int"),
            ("nbColis",        "Nb colis",     "int"),
            ("codeTournee",    "Code tournée", "int"),
            ("codeClient",     "Code client",  "int"),
        ]
    },
    "consoCO2": {
        "pk": "codeVehicule",
        "fields": [
            ("codeVehicule",   "Code véhicule", "int"),
            ("dateAnnee",      "Année",         "str"),
            ("CO2gKm",         "CO2 g/km",      "int"),
        ]
    },
    "Annee": {
        "pk": "dateAnnee",
        "fields": [
            ("dateAnnee", "Année", "str"),
        ]
    },
    "appartenir": {
        "pk": "codeTournee",
        "fields": [
            ("codeTournee", "Code tournée", "int"),
            ("codeEntree",  "Code entrée",  "int"),
        ]
    },
}

# ─────────────────────────────────────────────────────
#  Champs auto-générés (PK auto-incrémentées) — jamais
#  comptés comme "manquants" car remplis par la BDD.
# ─────────────────────────────────────────────────────
AUTO_PK_LABELS = {"Code (auto)"}   # correspond au label utilisé dans TABLES_META


class PageGestion(tk.Frame):
    def __init__(self, parent, ctrl):
        super().__init__(parent, bg=C_BG)
        self.ctrl  = ctrl
        self._vars = {}
        self._cur  = None
        self._cols = []
        top = tk.Frame(self, bg=C_PANEL, pady=8)
        top.pack(fill="x")
        tk.Label(top, text="📦  Gestion des données – Gestion",
                 font=FONT_H1, bg=C_PANEL, fg=C_TEXT).pack(side="left", padx=16)
        btn(top, "◀ Accueil", lambda: ctrl.show("PageAccueil"), color="#444").pack(side="right", padx=8)
        body = tk.Frame(self, bg=C_BG)
        body.pack(fill="both", expand=True)
        side = tk.Frame(body, bg=C_SIDEBAR, width=175)
        side.pack(side="left", fill="y")
        side.pack_propagate(False)
        tk.Label(side, text="Tables", font=FONT_H2, bg=C_SIDEBAR, fg=C_ACCENT).pack(pady=10)
        self._lb = tk.Listbox(side, bg=C_SIDEBAR, fg=C_TEXT, font=FONT_BODY,
                              selectbackground=C_ACCENT, selectforeground="#000",
                              relief="flat", bd=0, activestyle="none")
        self._lb.pack(fill="both", expand=True, padx=6)
        for t in TABLES_META:
            self._lb.insert("end", t)
        self._lb.bind("<<ListboxSelect>>", self._on_table)
        right = tk.Frame(body, bg=C_BG)
        right.pack(fill="both", expand=True)
        self._tw = tk.Frame(right, bg=C_BG, height=200)
        self._tw.pack(fill="x", padx=8, pady=8)
        self._tw.pack_propagate(False)
        self._tree = None
        self._form_lf = section(right, "Formulaire")
        self._form_lf.pack(fill="x", padx=8, pady=4)
        self._form_inner = tk.Frame(self._form_lf, bg=C_BG)
        self._form_inner.pack(fill="x", padx=8, pady=8)
        bbar = tk.Frame(right, bg=C_BG)
        bbar.pack(pady=8)
        btn(bbar, "➕ Insérer",   self._do_insert, color=C_GREEN2).pack(side="left", padx=6)
        btn(bbar, "✏️ Modifier",  self._do_update, color=C_ORANGE).pack(side="left", padx=6)
        btn(bbar, "🗑️ Supprimer", self._do_delete, color=C_RED).pack(side="left", padx=6)
        btn(bbar, "🔄 Vider",     self._clear_form, color="#555").pack(side="left", padx=6)
        self._status = tk.Label(right, text="", font=FONT_SM, bg=C_BG, fg=C_ACCENT)
        self._status.pack()

    # ── helpers ──────────────────────────────────────

    def _on_table(self, _=None):
        sel = self._lb.curselection()
        if not sel: return
        self._cur = self._lb.get(sel[0])
        self._load_data()
        self._build_form()

    def _load_data(self):
        try:
            cols, rows = run_sql(f"SELECT * FROM `{self._cur}`")
            self._cols = cols
            for w in self._tw.winfo_children(): w.destroy()
            self._tree = make_tree(self._tw, cols)
            fill_tree(self._tree, rows)
            self._tree.bind("<<TreeviewSelect>>", self._on_row)
        except Exception as e:
            messagebox.showerror("Erreur", str(e))

    def _build_form(self):
        for w in self._form_inner.winfo_children(): w.destroy()
        self._vars = {}
        self._field_defs = []   # ← mémoriser les defs pour la validation
        meta = TABLES_META.get(self._cur)
        fields = meta["fields"] if meta else [(c, c, "str") for c in self._cols]
        for i, field_def in enumerate(fields):
            fname = field_def[0]; flabel = field_def[1]; ftype = field_def[2]
            r, c2 = divmod(i, 2)
            tk.Label(self._form_inner, text=flabel + " :",
                     bg=C_BG, fg=C_DIM, font=FONT_SM, width=22, anchor="e"
                     ).grid(row=r, column=c2*2, padx=(8,2), pady=4, sticky="e")
            var = tk.StringVar()
            if ftype == "choice" and len(field_def) > 3:
                w = ttk.Combobox(self._form_inner, textvariable=var,
                                 values=field_def[3], state="readonly", width=22)
            else:
                w = tk.Entry(self._form_inner, textvariable=var,
                             bg=C_PANEL, fg=C_TEXT, font=FONT_BODY,
                             insertbackground=C_TEXT, relief="flat", width=24)
            w.grid(row=r, column=c2*2+1, padx=(2,8), pady=4, sticky="w")
            self._vars[fname] = var
            self._field_defs.append(field_def)

    def _on_row(self, _=None):
        sel = self._tree.selection()
        if not sel: return
        vals = self._tree.item(sel[0])["values"]
        for fname, var in self._vars.items():
            if fname in self._cols:
                idx = self._cols.index(fname)
                var.set(vals[idx] if idx < len(vals) else "")

    def _clear_form(self):
        for v in self._vars.values(): v.set("")

    # ── VALIDATION : champs manquants ────────────────

    def _get_missing_fields(self, skip_pk=False):
        """
        Retourne la liste des libellés de champs non remplis.
        - Les clés primaires auto (label == 'Code (auto)') sont toujours ignorées.
        - Si skip_pk=True, la PK de la table est également ignorée
          (utile pour INSERT où la BDD génère l'ID).
        """
        meta = TABLES_META.get(self._cur)
        pk_fname = meta["pk"] if meta else (self._cols[0] if self._cols else None)

        missing = []
        for field_def in self._field_defs:
            fname  = field_def[0]
            flabel = field_def[1]

            # Ignorer toujours les colonnes auto-incrémentées
            if flabel in AUTO_PK_LABELS:
                continue
            # En INSERT, ignorer aussi la PK si elle est auto
            if skip_pk and fname == pk_fname:
                continue

            val = self._vars.get(fname, tk.StringVar()).get().strip()
            if not val:
                missing.append(flabel)

        return missing

    def _warn_incomplete(self, missing_labels, action="valider votre saisie"):
        """
        Affiche une boîte de dialogue personnalisée :
        - « Oui » → continuer quand même
        - « Non » → retourner au formulaire pour corriger
        Retourne True si l'utilisateur veut continuer, False sinon.
        """
        manquants = "\n".join(f"   • {lbl}" for lbl in missing_labels)
        message = (
            f"⚠️  Voulez-vous vraiment {action} ?\n\n"
            f"Il vous manque des informations :\n{manquants}\n\n"
            "Cliquez sur « Non » pour corriger votre saisie."
        )
        return messagebox.askyesno(
            "Saisie incomplète",
            message,
            icon="warning"
        )

    # ── GESTION ─────────────────────────────────────────

    def _do_insert(self):
        if not self._cur: return

        # Vérification champs manquants (PK auto ignorée)
        missing = self._get_missing_fields(skip_pk=True)
        if missing:
            continuer = self._warn_incomplete(missing, action="valider votre saisie")
            if not continuer:
                # L'utilisateur veut corriger → on reste sur le formulaire
                self._status.config(
                    text="✏️  Corrigez les champs manquants puis réessayez.",
                    fg=C_ORANGE)
                return

        vals = {k: v.get() for k, v in self._vars.items() if v.get().strip()}
        if not vals:
            messagebox.showwarning("Attention", "Remplissez au moins un champ."); return
        sql = (f"INSERT INTO `{self._cur}` ({', '.join('`'+k+'`' for k in vals)}) "
               f"VALUES ({', '.join(['%s']*len(vals))})")
        try:
            run_sql(sql, list(vals.values()), fetch=False)
            self._status.config(text="✅ Insertion réussie", fg=C_GREEN2)
            self._load_data()
        except Exception as e:
            messagebox.showerror("Erreur INSERT", str(e))

    def _do_update(self):
        if not self._cur: return
        meta = TABLES_META.get(self._cur)
        pk = meta["pk"] if meta else self._cols[0]
        pk_val = self._vars.get(pk, tk.StringVar()).get()
        if not pk_val:
            messagebox.showwarning("Attention", f"Clé primaire ({pk}) obligatoire."); return

        # Vérification champs manquants (la PK est déjà renseignée)
        missing = self._get_missing_fields(skip_pk=False)
        # On retire la PK de la liste car elle vient d'être vérifiée
        meta_pk_label = next(
            (fd[1] for fd in self._field_defs if fd[0] == pk), None)
        if meta_pk_label and meta_pk_label in missing:
            missing.remove(meta_pk_label)

        if missing:
            continuer = self._warn_incomplete(missing, action="valider la modification")
            if not continuer:
                self._status.config(
                    text="✏️  Corrigez les champs manquants puis réessayez.",
                    fg=C_ORANGE)
                return

        upd = {k: v.get() for k, v in self._vars.items()
               if k != pk and v.get().strip()}
        if not upd:
            messagebox.showwarning("Attention", "Aucun champ à modifier."); return
        sql = (f"UPDATE `{self._cur}` SET "
               + ", ".join(f"`{k}`=%s" for k in upd)
               + f" WHERE `{pk}`=%s")
        try:
            run_sql(sql, list(upd.values()) + [pk_val], fetch=False)
            self._status.config(text="✅ Modification réussie", fg=C_ORANGE)
            self._load_data()
        except Exception as e:
            messagebox.showerror("Erreur UPDATE", str(e))

    def _do_delete(self):
        if not self._cur: return
        meta = TABLES_META.get(self._cur)
        pk = meta["pk"] if meta else self._cols[0]
        pk_val = self._vars.get(pk, tk.StringVar()).get()
        if not pk_val:
            messagebox.showwarning("Attention", f"Clé primaire ({pk}) obligatoire."); return
        if not messagebox.askyesno("Confirmer",
                                   f"Supprimer {pk} = {pk_val} dans {self._cur} ?"):
            return
        try:
            run_sql(f"DELETE FROM `{self._cur}` WHERE `{pk}`=%s",
                    [pk_val], fetch=False)
            self._status.config(text="🗑️ Suppression réussie", fg=C_RED)
            self._load_data()
        except Exception as e:
            messagebox.showerror("Erreur DELETE", str(e))

# ════════════════════════════════════════════════════
#  PAGE IMPORT CSV
# ════════════════════════════════════════════════════
def normalize_date(s):
    s = s.strip()
    m = re.match(r"^(\d{2})/(\d{2})/(\d{4})$", s)
    if m: return f"{m.group(3)}-{m.group(2)}-{m.group(1)}"
    return s

def normalize_str(s):
    return re.sub(r"\s+", " ", s).strip()

CSV_PROFILES = {
    "vehicule_livreur.csv": {
        "label":   "Véhicules & Livreurs (vehicule_livreur.csv)",
        "handler": "vehicule_livreur",
    },
    "tournee.csv": {
        "label":   "Tournées (tournee.csv)",
        "handler": "tournee",
    },
    "livraison.csv": {
        "label":   "Livraisons (livraison.csv)",
        "handler": "livraison",
    },
    "partenaire.csv": {
        "label":   "Partenaires (partenaire.csv)",
        "handler": "partenaire",
    },
    "entree.csv": {
        "label":   "Entrées (entree.csv)",
        "handler": "entree",
    },
}

class PageImport(tk.Frame):
    def __init__(self, parent, ctrl):
        super().__init__(parent, bg=C_BG)
        self.ctrl = ctrl
        top = tk.Frame(self, bg=C_PANEL, pady=8)
        top.pack(fill="x")
        tk.Label(top, text="📂  Import CSV – Données 2026",
                 font=FONT_H1, bg=C_PANEL, fg=C_TEXT).pack(side="left", padx=16)
        btn(top, "◀ Accueil", lambda: ctrl.show("PageAccueil"), color="#444").pack(side="right", padx=8)
        body = tk.Frame(self, bg=C_BG)
        body.pack(fill="both", expand=True, padx=14, pady=10)
        cfg = section(body, "Configuration")
        cfg.pack(fill="x", pady=(0,8))
        r1 = tk.Frame(cfg, bg=C_BG); r1.pack(fill="x", padx=8, pady=4)
        tk.Label(r1, text="Fichier CSV :", bg=C_BG, fg=C_TEXT,
                 font=FONT_BODY, width=16, anchor="w").pack(side="left")
        self._var_file = tk.StringVar()
        tk.Entry(r1, textvariable=self._var_file, bg=C_PANEL, fg=C_TEXT,
                 font=FONT_BODY, insertbackground=C_TEXT, relief="flat",
                 width=52).pack(side="left", padx=6)
        btn(r1, "📁 Parcourir", self._browse, color="#555").pack(side="left")
        r2 = tk.Frame(cfg, bg=C_BG); r2.pack(fill="x", padx=8, pady=4)
        tk.Label(r2, text="Profil :", bg=C_BG, fg=C_TEXT,
                 font=FONT_BODY, width=16, anchor="w").pack(side="left")
        self._var_profile = tk.StringVar()
        profile_labels = [v["label"] for v in CSV_PROFILES.values()]
        self._cb_profile = ttk.Combobox(r2, textvariable=self._var_profile,
                                        values=profile_labels, state="readonly", width=50)
        self._cb_profile.pack(side="left", padx=6)
        r3 = tk.Frame(cfg, bg=C_BG); r3.pack(fill="x", padx=8, pady=4)
        tk.Label(r3, text="Encodage :", bg=C_BG, fg=C_TEXT,
                 font=FONT_BODY, width=16, anchor="w").pack(side="left")
        self._var_enc = tk.StringVar(value="latin-1")
        for enc in ["utf-8", "utf-8-sig", "latin-1", "cp1252"]:
            tk.Radiobutton(r3, text=enc, variable=self._var_enc, value=enc,
                           bg=C_BG, fg=C_TEXT, selectcolor=C_PANEL,
                           activebackground=C_BG, font=FONT_SM).pack(side="left", padx=8)
        brow = tk.Frame(body, bg=C_BG); brow.pack(fill="x", pady=6)
        btn(brow, "👁️ Prévisualiser", self._preview, color=C_BLUE).pack(side="left", padx=6)
        btn(brow, "⬆️ Importer",      self._import,  color=C_GREEN2).pack(side="left", padx=6)
        btn(brow, "🧹 Vider journal",  self._clear_log, color="#555").pack(side="right", padx=6)
        nb = ttk.Notebook(body)
        nb.pack(fill="both", expand=True)
        self._prev_frame = tk.Frame(nb, bg=C_BG)
        nb.add(self._prev_frame, text="  Aperçu  ")
        log_frame = tk.Frame(nb, bg=C_BG)
        nb.add(log_frame, text="  Journal  ")
        self._log = scrolledtext.ScrolledText(
            log_frame, bg="#0B1622", fg="#C8FAD6", font=FONT_CODE,
            insertbackground=C_TEXT, relief="flat", state="disabled")
        self._log.pack(fill="both", expand=True, padx=4, pady=4)

    def _browse(self):
        p = filedialog.askopenfilename(
            filetypes=[("CSV", "*.csv"), ("Tous", "*.*")])
        if p:
            self._var_file.set(p)
            fname = os.path.basename(p)
            for key, prof in CSV_PROFILES.items():
                if key == fname:
                    self._var_profile.set(prof["label"]); break

    def _log_write(self, msg, ok=True):
        self._log.config(state="normal")
        ts = datetime.now().strftime("%H:%M:%S")
        self._log.insert("end", f"[{ts}]  {'✅' if ok else '❌'}  {msg}\n")
        self._log.see("end")
        self._log.config(state="disabled")

    def _clear_log(self):
        self._log.config(state="normal")
        self._log.delete("1.0", "end")
        self._log.config(state="disabled")

    def _read_csv(self):
        path = self._var_file.get()
        if not path or not os.path.exists(path):
            messagebox.showwarning("Attention", "Sélectionnez un fichier CSV valide.")
            return None
        enc = self._var_enc.get()
        with open(path, newline="", encoding=enc, errors="replace") as f:
            rows = list(csv.reader(f, delimiter=";"))
        return rows

    def _get_handler(self):
        lbl_sel = self._var_profile.get()
        for key, prof in CSV_PROFILES.items():
            if prof["label"] == lbl_sel:
                return prof["handler"]
        return None

    def _preview(self):
        for w in self._prev_frame.winfo_children(): w.destroy()
        rows = self._read_csv()
        if rows is None: return
        cols = rows[0]; data = rows[1:min(51, len(rows))]
        t = make_tree(self._prev_frame, cols)
        fill_tree(t, data)
        tk.Label(self._prev_frame,
                 text=f"{len(data)} lignes affichées / {len(rows)-1} total",
                 bg=C_BG, fg=C_DIM, font=FONT_SM).pack(pady=4)

    def _import(self):
        handler = self._get_handler()
        if not handler:
            messagebox.showwarning("Attention", "Sélectionnez un profil d'import."); return
        rows = self._read_csv()
        if rows is None: return
        headers = [h.strip() for h in rows[0]]
        data = rows[1:]
        getattr(self, f"_import_{handler}")(headers, data)

    def _import_partenaire(self, headers, data):
        ok = err = skip = 0
        seen = set()
        conn = get_conn(); cur = conn.cursor()
        cur.execute("SELECT LOWER(TRIM(nomPartenaire)), LOWER(TRIM(Ville)) FROM Partenaire")
        existing = set(cur.fetchall())
        for row in data:
            if len(row) < 2: continue
            nom = normalize_str(row[0]); ville = normalize_str(row[1])
            key = (nom.lower(), ville.lower())
            if key in existing or key in seen:
                skip += 1; continue
            seen.add(key)
            try:
                cur.execute("INSERT INTO Partenaire (nomPartenaire, Ville) VALUES (%s,%s)", (nom, ville))
                ok += 1
            except Exception as e:
                self._log_write(f"Partenaire {nom}: {e}", False); err += 1
        conn.commit(); conn.close()
        self._log_write(f"Partenaires : {ok} insérés, {skip} doublons ignorés, {err} erreurs.")
        messagebox.showinfo("Import Partenaires", f"{ok} insérés · {skip} doublons · {err} erreurs")

    def _import_vehicule_livreur(self, headers, data):
        ok_v = err_v = skip_v = 0
        conn = get_conn(); cur = conn.cursor()
        cur.execute("SELECT LOWER(typeVehicule), autonomie, capacite FROM vehicule")
        existing_v = set(cur.fetchall())
        for row in data:
            if len(row) < 4: continue
            typeV = normalize_str(row[0]) if row[0].strip() else None
            if not typeV: continue
            try:
                auto = int(row[1]); cap = int(row[2]); nb = int(row[3])
                key = (typeV.lower(), auto, cap)
                if key in existing_v:
                    skip_v += 1; continue
                cur.execute(
                    "INSERT INTO vehicule (typeVehicule, nombreVehicule, autonomie, capacite)"
                    " VALUES (%s,%s,%s,%s)", (typeV, nb, auto, cap))
                existing_v.add(key); ok_v += 1
            except Exception as e:
                self._log_write(f"Véhicule {row}: {e}", False); err_v += 1
        ok_l = err_l = skip_l = 0
        cur.execute("SELECT LOWER(nomLivreur), LOWER(PrenomLivreur) FROM livreur")
        existing_l = set(cur.fetchall())
        for row in data:
            if len(row) < 7: continue
            nom = normalize_str(row[4]) if row[4].strip() else None
            prenom = normalize_str(row[5]) if row[5].strip() else None
            date_raw = row[6].strip() if row[6].strip() else None
            if not nom or not prenom or not date_raw: continue
            key = (nom.lower(), prenom.lower())
            if key in existing_l:
                skip_l += 1; continue
            date_emb = normalize_date(date_raw)
            try:
                cur.execute(
                    "INSERT INTO livreur (nomLivreur, PrenomLivreur, dateEmbauche)"
                    " VALUES (%s,%s,%s)", (nom, prenom, date_emb))
                existing_l.add(key); ok_l += 1
            except Exception as e:
                self._log_write(f"Livreur {nom}: {e}", False); err_l += 1
        conn.commit(); conn.close()
        self._log_write(f"Véhicules  : {ok_v} insérés, {skip_v} doublons, {err_v} erreurs.")
        self._log_write(f"Livreurs   : {ok_l} insérés, {skip_l} doublons, {err_l} erreurs.")
        messagebox.showinfo("Import Véhicules & Livreurs",
            f"Véhicules : {ok_v} insérés · {skip_v} doublons\n"
            f"Livreurs  : {ok_l} insérés · {skip_l} doublons")

    def _import_entree(self, headers, data):
        ok = err = 0
        conn = get_conn(); cur = conn.cursor()
        for row in data:
            if len(row) < 3: continue
            date_raw = row[0].strip(); qte_raw = row[1].strip()
            part_nom = normalize_str(row[2])
            if not date_raw or not qte_raw or not part_nom: continue
            date_e = normalize_date(date_raw)
            try:
                qte = int(qte_raw)
                cur.execute(
                    "SELECT codePartenaire FROM Partenaire "
                    "WHERE LOWER(TRIM(nomPartenaire)) LIKE %s LIMIT 1",
                    (f"%{part_nom.lower()[:8]}%",))
                res = cur.fetchone()
                code_part = res[0] if res else None
                cur.execute(
                    "INSERT INTO entree (dateEntree, quantiteColis, codePartenaire)"
                    " VALUES (%s,%s,%s)", (date_e, qte, code_part))
                ok += 1
            except Exception as e:
                self._log_write(f"Entrée {row}: {e}", False); err += 1
        conn.commit(); conn.close()
        self._log_write(f"Entrées : {ok} insérées, {err} erreurs.")
        messagebox.showinfo("Import Entrées", f"{ok} insérées · {err} erreurs")

    def _import_tournee(self, headers, data):
        ok = err = 0
        conn = get_conn(); cur = conn.cursor()
        for row in data:
            if len(row) < 5: continue
            date_raw = row[0].strip(); type_v = normalize_str(row[1])
            livreur_nom = normalize_str(row[4])
            if not date_raw or not type_v or not livreur_nom: continue
            date_t = normalize_date(date_raw)
            try:
                cur.execute(
                    "SELECT codeVehicule FROM vehicule "
                    "WHERE REPLACE(LOWER(typeVehicule),' ','') LIKE %s LIMIT 1",
                    (f"%{type_v.lower().replace(' ','')[:5]}%",))
                rv = cur.fetchone(); code_v = rv[0] if rv else None
                cur.execute(
                    "SELECT codeLivreur FROM livreur "
                    "WHERE LOWER(nomLivreur) LIKE %s LIMIT 1",
                    (f"%{livreur_nom.lower()[:5]}%",))
                rl = cur.fetchone(); code_l = rl[0] if rl else None
                if not code_v or not code_l:
                    self._log_write(
                        f"Tournée {date_t}: veh={code_v} liv={code_l} non trouvés", False)
                    err += 1; continue
                cur.execute(
                    "INSERT INTO tournee (dateSortie, codeLivreur, codeVehicule)"
                    " VALUES (%s,%s,%s)", (date_t, code_l, code_v))
                ok += 1
            except Exception as e:
                self._log_write(f"Tournée {row}: {e}", False); err += 1
        conn.commit(); conn.close()
        self._log_write(f"Tournées : {ok} insérées, {err} erreurs.")
        messagebox.showinfo("Import Tournées", f"{ok} insérées · {err} erreurs")

    def _import_livraison(self, headers, data):
        ok = err = 0
        conn = get_conn(); cur = conn.cursor()
        for row in data:
            if len(row) < 7: continue
            date_raw = row[0].strip(); client_nom = normalize_str(row[1])
            poids_raw = re.sub(r"[^\d]", "", row[4])
            nb_raw = row[6].strip()
            livreur_nom = normalize_str(row[7]) if len(row) > 7 else ""
            if not date_raw or not client_nom: continue
            date_l = normalize_date(date_raw)
            try:
                poids = int(poids_raw) if poids_raw else 0
                nb = int(nb_raw) if nb_raw else 1
                cur.execute(
                    "SELECT codeClient FROM Client "
                    "WHERE LOWER(TRIM(NomClient)) LIKE %s LIMIT 1",
                    (f"%{client_nom.lower()[:8]}%",))
                rc = cur.fetchone()
                if rc:
                    code_c = rc[0]
                else:
                    ville = normalize_str(row[2]) if len(row) > 2 else "?"
                    adresse = normalize_str(row[5]) if len(row) > 5 else ""
                    cp_match = re.search(r"\b(\d{5})\b", adresse)
                    cp = cp_match.group(1) if cp_match else "00000"
                    rue = re.sub(r"\d{5}.*$", "", adresse).strip()
                    cur.execute(
                        "INSERT INTO Client (nomClient, RueClient, CPClient, VilleClient)"
                        " VALUES (%s,%s,%s,%s)", (client_nom, rue or "?", cp, ville))
                    code_c = cur.lastrowid
                code_t = None
                if livreur_nom:
                    cur.execute(
                        "SELECT t.codeTournee FROM tournee t "
                        "JOIN livreur l ON t.codeLivreur = l.codeLivreur "
                        "WHERE t.dateSortie = %s "
                        "AND LOWER(l.nomLivreur) LIKE %s LIMIT 1",
                        (date_l, f"%{livreur_nom.lower()[:5]}%"))
                    rt = cur.fetchone(); code_t = rt[0] if rt else None
                cur.execute(
                    "INSERT INTO Livraison (poidsTotal, nbColis, codeTournee, codeClient)"
                    " VALUES (%s,%s,%s,%s)", (poids, nb, code_t, code_c))
                ok += 1
            except Exception as e:
                self._log_write(f"Livraison {row}: {e}", False); err += 1
        conn.commit(); conn.close()
        self._log_write(f"Livraisons : {ok} insérées, {err} erreurs.")
        messagebox.showinfo("Import Livraisons", f"{ok} insérées · {err} erreurs")

# ════════════════════════════════════════════════════
#  PAGE REQUÊTES  (10 requêtes réelles GreenSD)
# ════════════════════════════════════════════════════
REQUETES = {
    "R1 – Nb livraisons par livreur (GROUP BY)": (C_ACCENT, """
SELECT l.codeLivreur, l.nomLivreur, l.PrenomLivreur,
       COUNT(li.codeLivraison) AS NombreLivraisons
FROM livreur l
JOIN tournee t   ON l.codeLivreur  = t.codeLivreur
JOIN Livraison li ON t.codeTournee = li.codeTournee
GROUP BY l.codeLivreur, l.nomLivreur, l.PrenomLivreur
ORDER BY NombreLivraisons DESC;
"""),
    "R2 – Livreurs avec > 1 livraison (HAVING)": (C_BLUE, """
SELECT COUNT(li.codeLivraison) AS NombreLivraisons,
       l.codeLivreur, l.nomLivreur, l.PrenomLivreur
FROM livreur l
JOIN tournee t   ON l.codeLivreur  = t.codeLivreur
JOIN Livraison li ON t.codeTournee = li.codeTournee
GROUP BY l.codeLivreur, l.nomLivreur, l.PrenomLivreur
HAVING COUNT(li.codeLivraison) > 1
ORDER BY NombreLivraisons DESC;
"""),
    "R3 – Véhicules sans tournée en 2025 (différence)": (C_PURPLE, """
SELECT codeVehicule, typeVehicule, autonomie, capacite
FROM vehicule
WHERE codeVehicule NOT IN (
    SELECT codeVehicule FROM tournee
    WHERE YEAR(dateSortie) = 2025
);
"""),
    "R4 – Vue vue_tournee + Velo-cargo": (C_ORANGE, """
CREATE OR REPLACE VIEW vue_tournee AS
SELECT l.codeLivreur, l.nomLivreur, l.PrenomLivreur,
       t.codeTournee, t.dateSortie,
       v.codeVehicule, v.typeVehicule, v.autonomie, v.capacite
FROM tournee t
JOIN livreur  l ON t.codeLivreur  = l.codeLivreur
JOIN vehicule v ON t.codeVehicule = v.codeVehicule;

SELECT COUNT(codeTournee) AS nb_tournee,
       codeVehicule, typeVehicule, autonomie, capacite
FROM vue_tournee
WHERE typeVehicule = 'Velo-cargo'
GROUP BY codeVehicule, typeVehicule, autonomie, capacite;
"""),
    "R5 – Nb tournées par type de véhicule": (C_GREEN2, """
SELECT COUNT(t.codeTournee) AS nb_tournee,
       v.typeVehicule, v.codeVehicule
FROM tournee t
JOIN vehicule v ON t.codeVehicule = v.codeVehicule
GROUP BY v.typeVehicule, v.codeVehicule;
"""),
    "R6 – Colis entrants par partenaire": (C_ACCENT, """
SELECT p.nomPartenaire, p.Ville,
       COUNT(e.codeEntree)  AS nb_entrees,
       SUM(e.quantiteColis) AS total_colis
FROM Partenaire p
JOIN entree e ON p.codePartenaire = e.codePartenaire
GROUP BY p.codePartenaire, p.nomPartenaire, p.Ville
ORDER BY total_colis DESC;
"""),
    "R7 – CO2 estimé par tournée": (C_BLUE, """
SELECT t.codeTournee, t.dateSortie, v.typeVehicule,
       c.CO2gKm,
       ROUND(v.autonomie * c.CO2gKm / 1000.0, 3) AS CO2_estime_kg
FROM tournee t
JOIN vehicule  v ON t.codeVehicule = v.codeVehicule
JOIN consoCO2  c ON v.codeVehicule = c.codeVehicule
               AND c.dateAnnee = YEAR(t.dateSortie)
ORDER BY CO2_estime_kg DESC;
"""),
    "R8 – INSERT nouveau livreur": (C_GREEN2, """
INSERT INTO livreur (nomLivreur, PrenomLivreur, dateEmbauche)
VALUES ('Niney', 'Pierre', '2026-03-29');
"""),
    "R9 – UPDATE adresse client DECATHLON": (C_ORANGE, """
UPDATE Client
SET RueClient   = '3 rue Amédée Gordini',
    CPClient    = '87280',
    VilleClient = 'Limoges'
WHERE NomClient = 'DECATHLON';
"""),
    "R10 – DELETE livreur Garnier": (C_RED, """
DELETE FROM livreur
WHERE nomLivreur = 'Garnier';
"""),
}

class PageRequetes(tk.Frame):
    def __init__(self, parent, ctrl):
        super().__init__(parent, bg=C_BG)
        self.ctrl = ctrl
        top = tk.Frame(self, bg=C_PANEL, pady=8)
        top.pack(fill="x")
        tk.Label(top, text="🔍  Requêtes SQL – GreenSD",
                 font=FONT_H1, bg=C_PANEL, fg=C_TEXT).pack(side="left", padx=16)
        btn(top, "◀ Accueil", lambda: ctrl.show("PageAccueil"), color="#444").pack(side="right", padx=8)
        body = tk.Frame(self, bg=C_BG)
        body.pack(fill="both", expand=True)
        side = tk.Frame(body, bg=C_SIDEBAR, width=240)
        side.pack(side="left", fill="y")
        side.pack_propagate(False)
        tk.Label(side, text="Requêtes", font=FONT_H2, bg=C_SIDEBAR, fg=C_ACCENT).pack(pady=10)
        self._lb = tk.Listbox(side, bg=C_SIDEBAR, fg=C_TEXT, font=FONT_SM,
                              selectbackground=C_ACCENT, selectforeground="#000",
                              relief="flat", bd=0, activestyle="none")
        self._lb.pack(fill="both", expand=True, padx=6)
        for name in REQUETES:
            self._lb.insert("end", name)
        self._lb.bind("<<ListboxSelect>>", self._on_select)
        right = tk.Frame(body, bg=C_BG)
        right.pack(fill="both", expand=True)
        edit_lf = section(right, "Éditeur SQL")
        edit_lf.pack(fill="x", padx=8, pady=(8,4))
        self._editor = scrolledtext.ScrolledText(
            edit_lf, height=9, bg="#0B1622", fg="#A8FF78",
            font=FONT_CODE, insertbackground=C_TEXT, relief="flat")
        self._editor.pack(fill="x", padx=4, pady=4)
        self._badge = tk.Label(right, text="", font=FONT_SM, bg=C_BG, fg=C_DIM)
        self._badge.pack(anchor="w", padx=12)
        brow = tk.Frame(right, bg=C_BG)
        brow.pack(fill="x", padx=8, pady=4)
        btn(brow, "▶ Exécuter",        self._run_one, color=C_GREEN2).pack(side="left", padx=6)
        btn(brow, "🗑️ Vider éditeur",   self._clear,   color="#555").pack(side="right", padx=6)
        self._res_wrap = tk.Frame(right, bg=C_BG)
        self._res_wrap.pack(fill="both", expand=True, padx=8, pady=4)
        self._lbl_res = tk.Label(right, text="", font=FONT_SM, bg=C_BG, fg=C_DIM)
        self._lbl_res.pack()

    def _on_select(self, _=None):
        sel = self._lb.curselection()
        if not sel: return
        name = self._lb.get(sel[0])
        color, sql = REQUETES[name]
        self._editor.delete("1.0", "end")
        self._editor.insert("end", sql.strip())
        self._badge.config(text=f"  {name}", fg=color)

    def _clear(self):
        self._editor.delete("1.0", "end")

    def _run_one(self):
        sql_block = self._editor.get("1.0", "end").strip()
        if not sql_block: return
        stmts = [s.strip() for s in sql_block.split(";") if s.strip()]
        last_cols = last_rows = None
        try:
            conn = get_conn(); cur = conn.cursor()
            for stmt in stmts:
                cur.execute(stmt)
                if cur.description:
                    last_cols = [d[0] for d in cur.description]
                    last_rows = cur.fetchall()
            conn.commit(); conn.close()
        except Exception as e:
            messagebox.showerror("Erreur SQL", str(e)); return
        for w in self._res_wrap.winfo_children(): w.destroy()
        if last_cols and last_rows is not None:
            t = make_tree(self._res_wrap, last_cols)
            fill_tree(t, last_rows)
            self._lbl_res.config(text=f"  {len(last_rows)} résultat(s)", fg=C_GREEN2)
        else:
            self._lbl_res.config(
                text="  ✅ Requête exécutée (DML – pas de résultat tabulaire)", fg=C_ORANGE)

    def _run_all(self):
        select_keys = [k for k in REQUETES
                       if any(k.startswith(f"R{i}") for i in range(1, 8))]
        results = []
        for k in select_keys:
            _, sql = REQUETES[k]
            stmts = [s.strip() for s in sql.strip().split(";") if s.strip()]
            try:
                conn = get_conn(); cur = conn.cursor()
                for s in stmts: cur.execute(s)
                conn.commit(); conn.close()
                results.append(f"✅  {k}")
            except Exception as e:
                results.append(f"❌  {k}\n     → {e}")
        messagebox.showinfo("Résultats R1–R7", "\n".join(results))

# ════════════════════════════════════════════════════
#  PAGE CO₂
# ════════════════════════════════════════════════════
class PageCO2(tk.Frame):
    def __init__(self, parent, ctrl):
        super().__init__(parent, bg=C_BG)
        self.ctrl = ctrl
        top = tk.Frame(self, bg=C_PANEL, pady=8)
        top.pack(fill="x")
        tk.Label(top, text=" Tableau de bord CO₂",
                 font=FONT_H1, bg=C_PANEL, fg=C_TEXT).pack(side="left", padx=16)
        btn(top, " Rafraîchir", self._load, color=C_ACCENT).pack(side="right", padx=6)
        btn(top, "◀ Accueil", lambda: ctrl.show("PageAccueil"), color="#444").pack(side="right", padx=8)
        self._body = tk.Frame(self, bg=C_BG)
        self._body.pack(fill="both", expand=True, padx=14, pady=10)
        self._load()

    def _load(self):
        for w in self._body.winfo_children(): w.destroy()
        kpi_row = tk.Frame(self._body, bg=C_BG)
        kpi_row.pack(fill="x", pady=(0,14))
        kpis = [
            ("Tournées",    "SELECT COUNT(*) FROM tournee",              C_ACCENT),
            ("Livreurs",    "SELECT COUNT(*) FROM livreur",              C_BLUE),
            ("Véhicules",   "SELECT COUNT(*) FROM vehicule",             C_ORANGE),
            ("Livraisons",  "SELECT COUNT(*) FROM Livraison",            C_GREEN2),
            ("Partenaires", "SELECT COUNT(*) FROM Partenaire",           C_PURPLE),
            (" Colis reçus", "SELECT SUM(quantiteColis) FROM entree",     C_RED),
        ]
        for label, sql, color in kpis:
            try:
                _, r = run_sql(sql)
                val = r[0][0] if r and r[0][0] is not None else "—"
            except:
                val = "N/A"
            card = tk.Frame(kpi_row, bg=color, width=140, height=75)
            card.pack(side="left", padx=6)
            card.pack_propagate(False)
            tk.Label(card, text=str(val), font=("Segoe UI", 20, "bold"),
                     bg=color, fg="white").pack(pady=(10,0))
            tk.Label(card, text=label, font=FONT_SM, bg=color, fg="white").pack()
        lf1 = section(self._body, "Coefficients CO₂ annuels (g/km)")
        lf1.pack(fill="x", pady=(0,8))
        try:
            cols, rows = run_sql(
                "SELECT c.dateAnnee AS Annee, v.typeVehicule AS Type, c.CO2gKm "
                "FROM consoCO2 c JOIN vehicule v ON c.codeVehicule = v.codeVehicule "
                "ORDER BY c.dateAnnee, v.typeVehicule")
            t = make_tree(lf1, cols)
            fill_tree(t, rows)
        except:
            tk.Label(lf1, text="Table consoCO2 non disponible",
                     bg=C_BG, fg=C_DIM, font=FONT_SM).pack()
        lf2 = section(self._body, "CO₂ estimé par type de véhicule")
        lf2.pack(fill="both", expand=True, pady=(0,4))
        try:
            cols2, rows2 = run_sql("""
                SELECT v.typeVehicule,
                       COUNT(DISTINCT t.codeTournee) AS nb_tournees,
                       c.CO2gKm AS coef_gKm,
                       ROUND(SUM(v.autonomie * c.CO2gKm)/1000.0, 2) AS CO2_estime_kg
                FROM tournee t
                JOIN vehicule v  ON t.codeVehicule = v.codeVehicule
                JOIN consoCO2 c  ON v.codeVehicule = c.codeVehicule
                                AND c.dateAnnee = YEAR(t.dateSortie)
                GROUP BY v.typeVehicule, c.CO2gKm
                ORDER BY CO2_estime_kg DESC
            """)
            t2 = make_tree(lf2, cols2)
            fill_tree(t2, rows2)
        except Exception as e:
            tk.Label(lf2, text=f"Données insuffisantes : {e}",
                     bg=C_BG, fg=C_DIM, font=FONT_SM).pack()

# ════════════════════════════════════════════════════
#  PAGE PARAMÈTRES
# ════════════════════════════════════════════════════
class PageSettings(tk.Frame):
    def __init__(self, parent, ctrl):
        super().__init__(parent, bg=C_BG)
        self.ctrl = ctrl
        top = tk.Frame(self, bg=C_PANEL, pady=8)
        top.pack(fill="x")
        tk.Label(top, text="⚙️  Paramètres de connexion MySQL",
                 font=FONT_H1, bg=C_PANEL, fg=C_TEXT).pack(side="left", padx=16)
        btn(top, "◀ Accueil", lambda: ctrl.show("PageAccueil"), color="#444").pack(side="right", padx=8)
        form = tk.Frame(self, bg=C_BG)
        form.pack(padx=60, pady=30)
        defs = [
            ("Hôte",            "host",     DB_CONFIG["host"]),
            ("Port",            "port",     str(DB_CONFIG["port"])),
            ("Utilisateur",     "user",     DB_CONFIG["user"]),
            ("Mot de passe",    "password", DB_CONFIG["password"]),
            ("Base de données", "database", DB_CONFIG["database"]),
        ]
        self._vars = {}
        for i, (lbl_txt, key, default) in enumerate(defs):
            var = tk.StringVar(value=default)
            entry_row(form, lbl_txt + " :", var, i,
                      show="*" if key == "password" else "")
            self._vars[key] = var
        brow = tk.Frame(self, bg=C_BG); brow.pack()
        btn(brow, "💾 Sauvegarder & tester", self._save, color=C_ACCENT).pack(padx=8)
        self._lbl = tk.Label(self, text="", font=FONT_BODY, bg=C_BG)
        self._lbl.pack(pady=8)

    def _save(self):
        global DB_CONFIG
        DB_CONFIG["host"]     = self._vars["host"].get()
        DB_CONFIG["port"]     = int(self._vars["port"].get() or 3306)
        DB_CONFIG["user"]     = self._vars["user"].get()
        DB_CONFIG["password"] = self._vars["password"].get()
        DB_CONFIG["database"] = self._vars["database"].get()
        try:
            c = get_conn(); c.close()
            self._lbl.config(text="✅ Connexion réussie !", fg=C_GREEN2)
        except Exception as e:
            self._lbl.config(text=f"❌ {e}", fg=C_RED)

# ════════════════════════════════════════════════════
#  APPLICATION PRINCIPALE
# ════════════════════════════════════════════════════
class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("GreenSD – Gestion Logistique Bas‑Carbone  |  BUT SD1")
        self.geometry("1280x780")
        self.minsize(1000, 650)
        self.config(bg=C_BG)
        self.resizable(True, True)
        self._build_topbar()
        self._build_pages()
        self.show("PageAccueil")

    def _build_topbar(self):
        bar = tk.Frame(self, bg=C_SIDEBAR, height=44)
        bar.pack(fill="x", side="top")
        bar.pack_propagate(False)
        tk.Label(bar, text="🌿 GreenSD", font=("Segoe UI", 13, "bold"),
                 bg=C_SIDEBAR, fg=C_ACCENT).pack(side="left", padx=14)
        tk.Frame(bar, bg=C_ACCENT, width=2).pack(side="left", fill="y", pady=6)
        nav = [
            ("🏠 Accueil",    "PageAccueil"),
            ("📋 Tables",     "PageTables"),
            ("📦 GESTION",     "PageGestion"),
            ("📂 Import CSV", "PageImport"),
            ("🔍 Requêtes",   "PageRequetes"),
            ("💨 CO₂",        "PageCO2"),
            ("⚙️ Paramètres", "PageSettings"),
        ]
        for label, page in nav:
            b = tk.Button(bar, text=label, bg=C_SIDEBAR, fg=C_TEXT,
                          font=FONT_SM, relief="flat", cursor="hand2",
                          activebackground=C_ACCENT, activeforeground="#000",
                          padx=10, pady=0, bd=0,
                          command=lambda p=page: self.show(p))
            b.pack(side="left", padx=2, pady=10)
        self._clock = tk.Label(bar, text="", bg=C_SIDEBAR, fg=C_DIM, font=FONT_SM)
        self._clock.pack(side="right", padx=14)
        self._tick()

    def _tick(self):
        self._clock.config(text=datetime.now().strftime("%d/%m/%Y  %H:%M:%S"))
        self.after(1000, self._tick)

    def _build_pages(self):
        self._container = tk.Frame(self, bg=C_BG)
        self._container.pack(fill="both", expand=True)
        self._container.grid_rowconfigure(0, weight=1)
        self._container.grid_columnconfigure(0, weight=1)
        self._pages = {}
        for Cls in [PageAccueil, PageTables, PageGestion,
                    PageImport, PageRequetes, PageCO2, PageSettings]:
            p = Cls(self._container, self)
            p.grid(row=0, column=0, sticky="nsew")
            self._pages[Cls.__name__] = p

    def show(self, name):
        self._pages[name].tkraise()

if __name__ == "__main__":
    app = App()
    app.mainloop()