# -*- coding: utf-8 -*-
"""
Created on Thu Apr  2 15:13:46 2026

@author: strachi
"""

import mysql.connector

import pandas 

from datetime import datetime

import re

import unicodedata

import math

def convertir_date(date_str):

    if date_str is None:
        return None

    if isinstance(date_str, float):
        if math.isnan(date_str):
            return None
        date_str = str(date_str)

    date_str = str(date_str).strip()
    if date_str == "":
        return None

    formats = ["%d/%m/%Y", "%d-%m-%Y", "%Y-%m-%d"]

    for fmt in formats:
        try:
            return datetime.strptime(date_str, fmt).strftime("%Y-%m-%d")
        except ValueError:
            continue

    return None

def nettoyer_texte(texte):
    texte = unicodedata.normalize('NFD', texte)
    texte = ''.join(c for c in texte if unicodedata.category(c) != 'Mn')
    texte = re.sub(r'[^a-zA-Z0-9 ]'," ", texte)
    return texte

def espace_tiret(texte):
    texte = texte.replace(" ", "-")
    return texte

def format_texte(texte):
    texte = texte.lower()
    texte = texte.title()
    return texte

def remplaceET (texte):
    texte = texte.replace("and", "&")
    return texte

def espaceEntreMinMaj(texte):
    texte = re.sub(r'([a-z])([A-Z])', r'\1 \2', texte)
    return texte

def supprEspace (texte):
    texte = texte.replace(" ", "")
    return texte

def clean(val):
    return None if pandas.isna(val) else val

dfTournee = pandas.read_csv("tournee.csv",encoding='ISO-8859-1', header=0, sep=";")
dfEntree = pandas.read_csv("entree.csv", encoding='ISO-8859-1',header=0, sep=";")
dfPartenaire = pandas.read_csv("partenaire.csv",encoding='ISO-8859-1', header=0, sep=";")
dfLivraison = pandas.read_csv("livraison.csv",encoding='ISO-8859-1', header=0, sep=";")
dfVehiculeLivreur = pandas.read_csv("vehicule_livreur.csv", encoding ='ISO-8859-1', header =0, sep=';')

db = mysql.connector.connect(host="localhost",user="root",password="",database="greensd-tdb")

c =db.cursor()
d = db.cursor(buffered=True)

#table partenaire
for index, ligne in dfPartenaire.iterrows() :
    c.execute("SELECT * FROM Partenaire WHERE nomPartenaire = %s", (ligne['nomPartenaire'],))
    result = c.fetchone()
    ligne['nomPartenaire'] = nettoyer_texte(ligne['nomPartenaire'])
    ligne['ville'] = nettoyer_texte(ligne['ville'])
    if result is None:
        requete = "INSERT INTO Partenaire ( nomPartenaire, ville) VALUES (%s, %s)"
        valeurs = (ligne['nomPartenaire'], ligne['ville'])
        c.execute(requete, valeurs)
        print(f"Ligne insérée : {valeurs}")
    else:
        print(f"{ligne['nomPartenaire']} : erreur, déjà insérée")

db.commit()

#table entree
for index, ligne in dfEntree.iterrows():
    ligne['partenaire'] = nettoyer_texte(ligne['partenaire'])

    c.execute("SELECT codePartenaire FROM Partenaire WHERE nomPartenaire = %s",(ligne['partenaire'],))
    result = c.fetchone()
    date_entree = convertir_date(ligne['date_entree'])
    if result is None:
        print(f"Partenaire introuvable : {ligne['partenaire']}")
        continue

    codePartenaire = result[0]

    c.execute("INSERT INTO Entree (dateEntree, quantiteColis, codePartenaire) VALUES (%s, %s, %s)",(date_entree, ligne['quantite colis'], codePartenaire))
db.commit()

#table livreur et vehicule
for index, ligne in dfVehiculeLivreur.iterrows():
  
    nom = str(ligne['nomLivreur']) if pandas.notna(ligne['nomLivreur']) else None
    if nom and ('DUPONT' in nom or 'RAMES' in nom):
        nom = format_texte(nom)

  
    dateEmbauche = convertir_date(ligne.get('dateEmbauche'))
    dfVehiculeLivreur['nomLivreur'] = dfVehiculeLivreur['nomLivreur'].fillna('Inconnu')

    prenom = ligne['prenomLivreur'] if pandas.notna(ligne['prenomLivreur']) else None

    if pandas.isna(ligne['typeVeh']) and  pandas.isna(ligne['autonomie']) and  pandas.isna(ligne['capacite']) :
        date_mysql = pandas.to_datetime(ligne['dateEmbauche'], dayfirst=True).strftime('%Y-%m-%d') if ligne.get('dateEmbauche') else None
        requete = "INSERT INTO livreur (nomLivreur, PrenomLivreur, dateEmbauche) VALUES (%s, %s, %s)"
        valeurs = (clean(nom), clean(prenom), clean(date_mysql))
        c.execute(requete, valeurs)
        result = c.fetchone()
        
    else:
          requete = "INSERT INTO vehicule (typeVehicule, nombreVehicule, autonomie, capacite) VALUES (%s, %s, %s, %s)"
          valeurs = (clean(ligne['typeVeh']), clean(ligne['nb Vehicule']), clean(ligne['autonomie']), clean(ligne['capacite']))
          c.execute(requete, valeurs)
          result = c.fetchone()


#table tournee
for index, ligne in dfTournee.iterrows():
    
    dateSortie = convertir_date(ligne['dateTour'])
    
    if 'Velo' in ligne['vehicule'] or 'Cargo' in ligne['vehicule']:
        vehicule = espace_tiret(ligne['vehicule'])
    elif ligne['vehicule'] == 'UTILITAIRE ELEC':
        vehicule = 'UtilitaireElectrique'
    else:
        vehicule = ligne['vehicule']
    
    prov_data = {}
    
    for i in range(1, 4):
        col = f'provenance{i}'
        val = ligne.get(col)
        
        if pandas.notna(val) and isinstance(val, str) and ' - ' in val:
            dateProv_str, lieuProv = val.split(' - ', 1)
            dateProv = convertir_date(dateProv_str)
        else:
            dateProv, lieuProv = None, None
        
        prov_data[f'date_{col}'] = dateProv
        prov_data[f'lieu_{col}'] = lieuProv
        
        d.execute("SELECT codeVehicule FROM vehicule WHERE typeVehicule = %s", (vehicule,))
        result = d.fetchone()
        codeVehicule = result[0] if result else None
        
        livreur_nom = ligne.get('livreur')
        if pandas.notna(livreur_nom):
            d.execute("SELECT codeLivreur FROM livreur WHERE nomLivreur = %s", (livreur_nom,))
            result = d.fetchone()
            if result:
                codeLivreur = result[0]
            else:
                print(f"Livreur introuvable : {livreur_nom}")
                continue
        else:
            print("Nom livreur manquant")
            continue
        
        if lieuProv:
            d.execute("SELECT codePartenaire FROM Partenaire WHERE nomPartenaire = %s", (lieuProv,))
            result = d.fetchone()
            codePartenaire = result[0] if result else None
        else:
            codePartenaire = None
        
        if dateProv and codePartenaire:
            d.execute("SELECT codeEntree FROM entree WHERE dateEntree = %s AND codePartenaire = %s", (dateProv, codePartenaire))
            result = d.fetchone()
            codeEntree = result[0] if result else None
        else:
            codeEntree = None
        
        if dateSortie and codeLivreur and codeVehicule:
            d.execute("INSERT INTO tournee (dateSortie, codeLivreur, codeVehicule) VALUES (%s, %s, %s)", (dateSortie, codeLivreur, codeVehicule))
db.commit()

#table livraison
livraisons_vues = set()

for index, ligne in dfLivraison.iterrows():
    dateSortie = convertir_date(ligne['date_sortie'])
    if 'Tri porteur' in ligne['véhicule'] :
        vehicule = supprEspace(ligne['véhicule'])

    d.execute("SELECT codeVehicule FROM vehicule WHERE typeVehicule = %s ",(vehicule,))
    result = d.fetchone()
    if result is None:
        print("Vehicule non trouvé :", vehicule)
        continue 

    codeVehicule = result[0]
    d.execute("SELECT codeLivreur FROM livreur WHERE nomLivreur = %s ", (ligne['livreur'],))
    codeLivreur = d.fetchone()[0]
    
    if pandas.notna(ligne['poids total']): 
        poidsTot =str(ligne['poids total'])           
        poidsTot = int(float(ligne['poids total'].replace('kg', '').strip()))
    else:
        poidsTot = input("saisir le poids total de la livraison (saisir que le nombre pas l'unité) : ") 

    if 'Boulangerie du centre' in ligne['client']:
        ligne['client'] = 'Boulangerie du Centre'
    elif 'Tech and Co' in ligne['client'] or 'Tech and Co' in ligne['client']:
        ligne['client'] = remplaceET(ligne['client'])
    
    adresse = ligne['adresse_complete']
    if adresse:
        adresse = ligne['adresse_complete']
        adresse = re.sub(r'\s*\d{5}.*', '', adresse)
        adresse = re.sub(r'\s*-\s*.*', '', adresse)
        adresse = re.sub(r',.*', '', adresse)
        adresse = supprEspace(adresse)
    
    if ligne['ville_client'].strip() in ['La Rochelle', 'LAROCHELLE', 'LaRochelle']:
        code_postal = '17000'
    elif ligne['ville_client'].strip() in ['Niort', 'NIORT']:
        code_postal = '79000'
    elif ligne['ville_client'].strip() == 'La Crèche':
        code_postal = '79260'
    elif ligne['ville_client'].strip() == 'Poitiers':
        code_postal = '86000'
    else:
        code_postal = None
    
    if 'LaRochelle' in ligne['ville_client']:
        ligne['ville_client'] = espaceEntreMinMaj(ligne['ville_client'])
    elif 'NIORT' in ligne['ville_client']:
        ligne['ville_client'] = format_texte(ligne['ville_client'])

    # Clé de déduplication basée sur les données nettoyées
    cle_doublon = (dateSortie, ligne['client'], adresse, code_postal, poidsTot, ligne['nb colis'], codeLivreur, codeVehicule)
    if cle_doublon in livraisons_vues:
        print(f"Doublon ignoré : {cle_doublon}")
        continue
    livraisons_vues.add(cle_doublon)

    d.execute("INSERT INTO client (NomClient, RueClient, CPClient, VilleClient) VALUES (%s, %s, %s ,%s)", (ligne['client'], adresse, code_postal, ligne['ville_client']))
    d.execute("SELECT codeClient FROM client WHERE nomClient =%s AND rueClient=%s AND CPClient=%s AND villeClient=%s", (ligne['client'], adresse, code_postal, ligne['ville_client']))
    print (ligne['client'], ligne['adresse_complete'],code_postal, ligne['ville_client'])
    result = d.fetchone()
    if result is not None : 
        codeClient= result[0]
    else : 
        codeClient = None
    d.execute("SELECT codeTournee FROM tournee WHERE codeLivreur=%s AND codeVehicule =%s ",(codeLivreur, codeVehicule))
    print(codeVehicule, codeLivreur)
    result = d.fetchone()
    if result is not None :
        codeTournee = result[0]
        d.execute("INSERT INTO livraison (poidsTotal, nbColis, codeTournee, codeClient) VALUES (%s, %s, %s, %s)", (poidsTot, ligne['nb colis'], codeTournee, codeClient))
    else : 
        codeTournee = None
    #d.execute("INSERT INTO livraison (poidsTotal, nbColis, codeTournee, codeClient) VALUES (%s, %s, %s, %s)", (poidsTot, ligne['nb colis'], codeTournee, codeClient))
db.commit()

db.close()