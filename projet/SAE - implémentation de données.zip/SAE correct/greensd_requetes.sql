
delete from livreur
where nomLivreur = 'Garnier';


SELECT *
FROM vehicule
WHERE codeVehicule NOT IN  (SELECT codeVehicule
			    			FROM tournee
		            		WHERE YEAR(dateSortie) = 2025);


insert into livreur values (41,'Niney' , 'Pierre', '2026-03-29');



UPDATE client
SET RueClient = '3 rue Amédée Gordini',
    CPClient = '87280',
    VilleClient = 'Limoges'
WHERE nomClient = 'DECATHLON';



SELECT COUNT(codeLivraison) AS NombreLivraisons,livreur.codeLivreur, nomLivreur, PrenomLivreur
FROM livreur, tournee, livraison
WHERE livreur.codeLivreur = tournee.codeLivreur
AND tournee.codeTournee = livraison.codeTournee
GROUP BY livreur.codeLivreur, nomLivreur, PrenomLivreur
HAVING COUNT(codeLivraison) > 1
ORDER BY NombreLivraisons DESC; 





Create view vue_tournee as
select Livreur.codeLivreur,nomLivreur, prenomLivreur,  codetournee, dateSortie , Vehicule.codeVehicule, typeVehicule , autonomie , capacite
From Tournee, Vehicule , livreur
WHERE tournee.codeLivreur = livreur.codeLivreur
AND tournee.codeVehicule = vehicule.codeVehicule;




SELECT COUNT(codetournee) AS nb_tournee, codeVehicule, typeVehicule, autonomie, capacite
FROM vue_tournee
WHERE typeVehicule = 'Velo-cargo'
GROUP BY codeVehicule, typeVehicule, autonomie, capacite;



Select count(codeTournee)  as nb_tournee, typeVehicule, vehicule.codeVehicule
from tournee, vehicule
where Tournee.codeVehicule = Vehicule.codeVehicule
group by typeVehicule, vehicule.codeVehicule;



insert into client values (21, ' Castorama ', '137 Avenue du 8 Mai 1945' , '86000', 'Poitiers');

 

UPDATE tournee
SET codeLivreur = 36
WHERE codeTournee = 2;