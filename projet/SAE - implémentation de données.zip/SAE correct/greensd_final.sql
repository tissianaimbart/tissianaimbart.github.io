-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  ven. 03 avr. 2026 à 13:17
-- Version du serveur :  5.7.17
-- Version de PHP :  5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `greensd-tdb`
--

-- --------------------------------------------------------

--
-- Structure de la table `annee`
--

CREATE TABLE `annee` (
  `dateAnnee` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `annee`
--

INSERT INTO `annee` (`dateAnnee`) VALUES
('2025'),
('2026');

-- --------------------------------------------------------

--
-- Structure de la table `appartenir`
--

CREATE TABLE `appartenir` (
  `codeTournee` int(11) NOT NULL,
  `codeEntree` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `appartenir`
--

INSERT INTO `appartenir` (`codeTournee`, `codeEntree`) VALUES
(8, 1),
(10, 2),
(9, 3),
(6, 4),
(3, 5),
(4, 6),
(5, 7),
(7, 8),
(2, 9),
(1, 10);

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

CREATE TABLE `client` (
  `codeClient` int(11) NOT NULL,
  `nomClient` varchar(50) NOT NULL,
  `RueClient` varchar(50) NOT NULL,
  `CPClient` char(5) NOT NULL,
  `VilleClient` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `client`
--

INSERT INTO `client` (`codeClient`, `nomClient`, `RueClient`, `CPClient`, `VilleClient`) VALUES
(11, 'Le fournil du Marais', '184 Avenue de La Rochelle', '79000', 'Niort'),
(12, 'DB PAIN', '7 Rue des Azalées', '79300', 'Bressuire'),
(13, 'DECATHLON', '3 rue Amédée Gordini', '87280', 'Limoges'),
(14, 'Epicerie Caucase', '21 Bis Rue Laurent Bonnevay', '79000', 'Niort'),
(15, 'Atelier de l\'Excellence Echiré', '66 Place de l\'Eglise', '79410', 'Echiré'),
(16, 'Execo', '62 Avenue du Maréchal de Lattre de Tassigny', '79000', 'Niort'),
(17, 'Autodistribution Talbot', '191 Avenue Arisitide Briand', '79200', 'Parthenay'),
(18, 'LA clef des champs', 'Zone Mude', '79000', 'Bessines'),
(19, 'Pharmacie Victor Hugo', ';5 Avenue Victor Hugo', '79100', 'Thouars'),
(20, 'Tobacco Europe', '7Pl. de l\'Europe', '17000', 'La Rochelle'),
(21, ' Castorama ', '137 Avenue du 8 Mai 1945', '86000', 'Poitiers'),
(22, 'Boulangerie du Centre ', '12RueduPort', '17000', 'La Rochelle'),
(23, 'Boulangerie du Centre', '12RueduPort', '17000', 'La Rochelle'),
(24, 'Panem', 'Zoneindustrielle', '79260', 'La Crèche'),
(25, 'Tech&Co', '4ruedelagare', '79000', 'Niort'),
(26, 'Tech & Co', '4ruedelagareNIORT', '79000', 'Niort'),
(27, 'Université de Poitiers', '8RueArchimède', '79000', 'Niort');

-- --------------------------------------------------------

--
-- Structure de la table `consoco2`
--

CREATE TABLE `consoco2` (
  `codeVehicule` int(11) NOT NULL,
  `dateAnnee` varchar(50) NOT NULL,
  `CO2gKm` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `consoco2`
--

INSERT INTO `consoco2` (`codeVehicule`, `dateAnnee`, `CO2gKm`) VALUES
(10, '2025', 4),
(10, '2026', 3),
(20, '2025', 9),
(20, '2026', 7),
(30, '2025', 21),
(30, '2026', 18),
(40, '2025', 21),
(40, '2026', 18),
(50, '2025', 4),
(50, '2026', 3),
(60, '2025', 9),
(60, '2026', 7);

-- --------------------------------------------------------

--
-- Structure de la table `entree`
--

CREATE TABLE `entree` (
  `codeEntree` int(11) NOT NULL,
  `dateEntree` date NOT NULL,
  `quantiteColis` int(11) NOT NULL,
  `codePartenaire` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `entree`
--

INSERT INTO `entree` (`codeEntree`, `dateEntree`, `quantiteColis`, `codePartenaire`) VALUES
(1, '2022-03-12', 2, 21),
(2, '2024-02-10', 7, 2),
(3, '2024-04-20', 3, 3),
(4, '2025-06-23', 9, 1),
(5, '2024-09-09', 11, 6),
(6, '2026-02-08', 4, 9),
(7, '2025-01-13', 10, 6),
(8, '2025-08-09', 1, 5),
(9, '2023-06-12', 6, 9),
(10, '2023-11-10', 13, 21),
(11, '2026-01-02', 120, 1),
(12, '2026-01-02', 200, 1),
(13, '2026-01-05', 80, 11),
(14, '2026-01-05', 100, 11),
(15, '2026-01-07', 50, 11),
(16, '2026-01-07', 60, 13);

-- --------------------------------------------------------

--
-- Structure de la table `livraison`
--

CREATE TABLE `livraison` (
  `codeLivraison` int(11) NOT NULL,
  `poidsTotal` int(11) NOT NULL,
  `nbColis` int(11) NOT NULL,
  `codeTournee` int(11) DEFAULT NULL,
  `codeClient` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `livraison`
--

INSERT INTO `livraison` (`codeLivraison`, `poidsTotal`, `nbColis`, `codeTournee`, `codeClient`) VALUES
(1, 15, 3, 1, 31),
(2, 25, 3, 2, 32),
(3, 3, 3, 3, 36),
(4, 12, 6, 4, 35),
(5, 21, 1, 5, 40),
(6, 10, 2, 6, 32),
(7, 9, 4, 7, 34),
(8, 15, 1, 8, 38),
(9, 13, 2, 9, 35),
(10, 23, 4, 10, 39),
(11, 12, 1, 17, 25);

-- --------------------------------------------------------

--
-- Structure de la table `livreur`
--

CREATE TABLE `livreur` (
  `codeLivreur` int(11) NOT NULL,
  `nomLivreur` varchar(50) NOT NULL,
  `PrenomLivreur` varchar(50) NOT NULL,
  `dateEmbauche` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `livreur`
--

INSERT INTO `livreur` (`codeLivreur`, `nomLivreur`, `PrenomLivreur`, `dateEmbauche`) VALUES
(31, 'Dupont', 'Xavier', '2023-03-05'),
(32, 'Trachi', 'Salma', '2025-07-12'),
(33, 'Maury', 'Amandine', '2024-10-09'),
(34, 'Imbart', 'Tissiana', '2022-02-16'),
(36, 'Laurent', 'Sofia', '2026-01-03'),
(37, 'Bureau', 'Laurent', '2022-05-23'),
(38, 'Payet', 'Eric', '2021-08-09'),
(39, 'Ibazizen', 'Mohamed', '2020-02-28'),
(40, 'Diakité', 'Ibrahima', '2026-02-10'),
(41, 'Niney', 'Pierre', '2026-03-29'),
(42, 'Martin', 'Paul', '2023-12-05'),
(43, 'Dupont', 'Alice', '2025-12-20'),
(44, 'Rames', 'Pedro', '2018-02-04'),
(45, 'Didon', 'Robin', '2023-09-28'),
(46, 'Rivierez', 'Solène', '2020-04-03');

-- --------------------------------------------------------

--
-- Structure de la table `partenaire`
--

CREATE TABLE `partenaire` (
  `codePartenaire` int(11) NOT NULL,
  `nomPartenaire` varchar(50) NOT NULL,
  `Ville` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `partenaire`
--

INSERT INTO `partenaire` (`codePartenaire`, `nomPartenaire`, `Ville`) VALUES
(1, 'Entrepot Nord', 'Lille'),
(2, 'Geodis', 'Moissy-Cramayel'),
(3, 'E-LOGISXL', 'Marly la Ville'),
(4, 'GFSLOGISTICS', 'Marseille'),
(5, 'EG PRESTATIONS', 'Vesoul'),
(6, 'DHL Hub ', 'Marly-la-Ville'),
(7, 'GFSLOGISTICS', 'Marseille'),
(8, 'XPO Logistics', 'Saint-Vulbas'),
(9, 'FM Logistics', 'Mormant'),
(10, 'ECODEM', 'Toulouse'),
(11, 'Hub Sud', '  Bordeaux'),
(12, 'Marche international', 'Rungis'),
(13, 'CRT', 'Lesquin'),
(14, 'Hub Miramas', 'St Martin de Crau');

-- --------------------------------------------------------

--
-- Structure de la table `tournee`
--

CREATE TABLE `tournee` (
  `codeTournee` int(11) NOT NULL,
  `dateSortie` date DEFAULT NULL,
  `codeLivreur` int(11) NOT NULL,
  `codeVehicule` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `tournee`
--

INSERT INTO `tournee` (`codeTournee`, `dateSortie`, `codeLivreur`, `codeVehicule`) VALUES
(1, '2023-04-21', 31, 30),
(2, '2025-07-20', 36, 30),
(3, '2026-02-10', 36, 60),
(4, '2025-04-23', 35, 20),
(5, '2026-02-18', 40, 50),
(6, '2025-08-03', 32, 50),
(7, '2022-03-02', 34, 30),
(8, '2022-08-19', 38, 60),
(9, '2024-12-10', 35, 40),
(10, '2024-03-10', 39, 20),
(11, '2026-01-10', 44, 30),
(12, '2026-01-10', 44, 30),
(13, '2026-01-10', 44, 30),
(14, '2026-01-12', 31, 30),
(15, '2026-01-12', 31, 30),
(16, '2026-01-12', 31, 30),
(17, '2026-01-12', 45, 10),
(18, '2026-01-12', 45, 10),
(19, '2026-01-12', 45, 10);

-- --------------------------------------------------------

--
-- Structure de la table `vehicule`
--

CREATE TABLE `vehicule` (
  `codeVehicule` int(11) NOT NULL,
  `typeVehicule` varchar(50) NOT NULL,
  `nombreVehicule` int(11) NOT NULL,
  `autonomie` int(11) NOT NULL,
  `capacite` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `vehicule`
--

INSERT INTO `vehicule` (`codeVehicule`, `typeVehicule`, `nombreVehicule`, `autonomie`, `capacite`) VALUES
(10, 'Velo-cargo', 20, 45, 120),
(20, 'Triporteur', 15, 60, 160),
(30, 'UtilitaireElectrique', 5, 150, 500),
(40, 'UtilitaireElectrique', 3, 200, 700),
(50, 'Velo-cargo', 3, 50, 130),
(60, 'Triporteur', 10, 80, 100),
(61, 'Velo-cargo', 10, 45, 120),
(62, 'Triporteur', 15, 60, 160),
(63, 'UtilitaireElectrique', 3, 150, 500),
(64, 'Velo-cargo', 3, 50, 130),
(65, 'UtilitaireElectrique', 2, 200, 700);

-- --------------------------------------------------------

--
-- Doublure de structure pour la vue `vue_tournee`
-- (Voir ci-dessous la vue réelle)
--
CREATE TABLE `vue_tournee` (
`codeLivreur` int(11)
,`nomLivreur` varchar(50)
,`prenomLivreur` varchar(50)
,`codetournee` int(11)
,`dateSortie` date
,`codeVehicule` int(11)
,`typeVehicule` varchar(50)
,`autonomie` int(11)
,`capacite` int(11)
);

-- --------------------------------------------------------

--
-- Structure de la vue `vue_tournee`
--
DROP TABLE IF EXISTS `vue_tournee`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vue_tournee`  AS  select `livreur`.`codeLivreur` AS `codeLivreur`,`livreur`.`nomLivreur` AS `nomLivreur`,`livreur`.`PrenomLivreur` AS `prenomLivreur`,`tournee`.`codeTournee` AS `codetournee`,`tournee`.`dateSortie` AS `dateSortie`,`vehicule`.`codeVehicule` AS `codeVehicule`,`vehicule`.`typeVehicule` AS `typeVehicule`,`vehicule`.`autonomie` AS `autonomie`,`vehicule`.`capacite` AS `capacite` from ((`tournee` join `vehicule`) join `livreur`) where ((`tournee`.`codeLivreur` = `livreur`.`codeLivreur`) and (`tournee`.`codeVehicule` = `vehicule`.`codeVehicule`)) ;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `annee`
--
ALTER TABLE `annee`
  ADD PRIMARY KEY (`dateAnnee`);

--
-- Index pour la table `appartenir`
--
ALTER TABLE `appartenir`
  ADD PRIMARY KEY (`codeTournee`,`codeEntree`),
  ADD KEY `codeEntree` (`codeEntree`);

--
-- Index pour la table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`codeClient`);

--
-- Index pour la table `consoco2`
--
ALTER TABLE `consoco2`
  ADD PRIMARY KEY (`codeVehicule`,`dateAnnee`),
  ADD KEY `dateAnnee` (`dateAnnee`);

--
-- Index pour la table `entree`
--
ALTER TABLE `entree`
  ADD PRIMARY KEY (`codeEntree`),
  ADD KEY `codePartenaire` (`codePartenaire`);

--
-- Index pour la table `livraison`
--
ALTER TABLE `livraison`
  ADD PRIMARY KEY (`codeLivraison`),
  ADD KEY `codeTournee` (`codeTournee`),
  ADD KEY `codeClient` (`codeClient`);

--
-- Index pour la table `livreur`
--
ALTER TABLE `livreur`
  ADD PRIMARY KEY (`codeLivreur`);

--
-- Index pour la table `partenaire`
--
ALTER TABLE `partenaire`
  ADD PRIMARY KEY (`codePartenaire`);

--
-- Index pour la table `tournee`
--
ALTER TABLE `tournee`
  ADD PRIMARY KEY (`codeTournee`),
  ADD KEY `codeLivreur` (`codeLivreur`),
  ADD KEY `codeVehicule` (`codeVehicule`);

--
-- Index pour la table `vehicule`
--
ALTER TABLE `vehicule`
  ADD PRIMARY KEY (`codeVehicule`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `client`
--
ALTER TABLE `client`
  MODIFY `codeClient` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT pour la table `entree`
--
ALTER TABLE `entree`
  MODIFY `codeEntree` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT pour la table `livraison`
--
ALTER TABLE `livraison`
  MODIFY `codeLivraison` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT pour la table `livreur`
--
ALTER TABLE `livreur`
  MODIFY `codeLivreur` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;
--
-- AUTO_INCREMENT pour la table `partenaire`
--
ALTER TABLE `partenaire`
  MODIFY `codePartenaire` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT pour la table `tournee`
--
ALTER TABLE `tournee`
  MODIFY `codeTournee` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT pour la table `vehicule`
--
ALTER TABLE `vehicule`
  MODIFY `codeVehicule` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;
--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `appartenir`
--
ALTER TABLE `appartenir`
  ADD CONSTRAINT `appartenir_ibfk_1` FOREIGN KEY (`codeTournee`) REFERENCES `tournee` (`codeTournee`),
  ADD CONSTRAINT `appartenir_ibfk_2` FOREIGN KEY (`codeEntree`) REFERENCES `entree` (`codeEntree`);

--
-- Contraintes pour la table `consoco2`
--
ALTER TABLE `consoco2`
  ADD CONSTRAINT `consoco2_ibfk_1` FOREIGN KEY (`codeVehicule`) REFERENCES `vehicule` (`codeVehicule`),
  ADD CONSTRAINT `consoco2_ibfk_2` FOREIGN KEY (`dateAnnee`) REFERENCES `annee` (`dateAnnee`);

--
-- Contraintes pour la table `entree`
--
ALTER TABLE `entree`
  ADD CONSTRAINT `entree_ibfk_1` FOREIGN KEY (`codePartenaire`) REFERENCES `partenaire` (`codePartenaire`);

--
-- Contraintes pour la table `livraison`
--
ALTER TABLE `livraison`
  ADD CONSTRAINT `livraison_ibfk_1` FOREIGN KEY (`codeTournee`) REFERENCES `tournee` (`codeTournee`),
  ADD CONSTRAINT `livraison_ibfk_2` FOREIGN KEY (`codeClient`) REFERENCES `client` (`codeClient`);

--
-- Contraintes pour la table `tournee`
--
ALTER TABLE `tournee`
  ADD CONSTRAINT `tournee_ibfk_1` FOREIGN KEY (`codeLivreur`) REFERENCES `livreur` (`codeLivreur`),
  ADD CONSTRAINT `tournee_ibfk_2` FOREIGN KEY (`codeVehicule`) REFERENCES `vehicule` (`codeVehicule`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
