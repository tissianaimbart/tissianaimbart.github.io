CREATE TABLE Partenaire(
   codePartenaire INT AUTO_INCREMENT,
   nomPartenaire VARCHAR(50) NOT NULL,
   Ville VARCHAR(50) NOT NULL,
   PRIMARY KEY(codePartenaire)
)ENGINE=InnoDB;

CREATE TABLE vehicule(
   codeVehicule INT AUTO_INCREMENT,
   typeVehicule VARCHAR(50) NOT NULL,
   nombreVehicule INT NOT NULL,
   autonomie INT NOT NULL,
   capacite INT NOT NULL,
   PRIMARY KEY(codeVehicule)
)ENGINE=InnoDB;

CREATE TABLE livreur(
   codeLivreur INT AUTO_INCREMENT,
   nomLivreur VARCHAR(50) NOT NULL,
   PrenomLivreur VARCHAR(50) NOT NULL,
   dateEmbauche DATE NOT NULL,
   PRIMARY KEY(codeLivreur)
)ENGINE=InnoDB;

CREATE TABLE Client(
   codeClient INT AUTO_INCREMENT,
   nomClient VARCHAR(50) NOT NULL,
   RueClient VARCHAR(50) NOT NULL,
   CPClient CHAR(5) NOT NULL,
   VilleClient VARCHAR(50) NOT NULL,
   PRIMARY KEY(codeClient)
)ENGINE=InnoDB;

CREATE TABLE Annee(
   dateAnnee VARCHAR(50),
   PRIMARY KEY(dateAnnee)
)ENGINE=InnoDB;

CREATE TABLE tournee(
   codeTournee INT AUTO_INCREMENT,
   dateSortie DATE,
   codeLivreur INT NOT NULL,
   codeVehicule INT NOT NULL,
   PRIMARY KEY(codeTournee),
   FOREIGN KEY(codeLivreur) REFERENCES livreur(codeLivreur),
   FOREIGN KEY(codeVehicule) REFERENCES vehicule(codeVehicule)
)ENGINE=InnoDB;

CREATE TABLE entree(
   codeEntree INT AUTO_INCREMENT,
   dateEntree DATE NOT NULL,
   quantiteColis INT NOT NULL,
   codePartenaire INT,
   PRIMARY KEY(codeEntree),
   FOREIGN KEY(codePartenaire) REFERENCES Partenaire(codePartenaire)
)ENGINE=InnoDB;

CREATE TABLE Livraison(
   codeLivraison INT AUTO_INCREMENT,
   poidsTotal INT NOT NULL,
   nbColis INT NOT NULL,
   codeTournee INT,
   codeClient INT NOT NULL,
   PRIMARY KEY(codeLivraison),
   FOREIGN KEY(codeTournee) REFERENCES tournee(codeTournee),
   FOREIGN KEY(codeClient) REFERENCES Client(codeClient)
)ENGINE=InnoDB;

CREATE TABLE consoCO2(
   codeVehicule INT,
   dateAnnee VARCHAR(50),
   CO2gKm INT NOT NULL,
   PRIMARY KEY(codeVehicule, dateAnnee),
   FOREIGN KEY(codeVehicule) REFERENCES vehicule(codeVehicule),
   FOREIGN KEY(dateAnnee) REFERENCES Annee(dateAnnee)
)ENGINE=InnoDB;

CREATE TABLE appartenir(
   codeTournee INT,
   codeEntree INT,
   PRIMARY KEY(codeTournee, codeEntree),
   FOREIGN KEY(codeTournee) REFERENCES tournee(codeTournee),
   FOREIGN KEY(codeEntree) REFERENCES entree(codeEntree)
)ENGINE=InnoDB;
