
insert into partenaire values(001,"Entrepot Nord","Lille");
insert into partenaire values(002,"Geodis","Moissy-Cramayel");
insert into partenaire values(003,"E-LOGISXL","Marly la Ville");
insert into partenaire values(004,"GFSLOGISTICS","Marseille");
insert into partenaire values(005,"EG PRESTATIONS","Vesoul");
insert into partenaire values(006,"DHL Hub ","Marly-la-Ville");
insert into partenaire values(007,"GFSLOGISTICS","Marseille");
insert into partenaire values(008,"XPO Logistics","Saint-Vulbas");
insert into partenaire values(009,"FM Logistics","Mormant");
insert into partenaire values(010,"ECODEM","Toulouse");

insert into vehicule values(0010,"Velo-cargo",20,45,120);
insert into vehicule values(0020,"Triporteur",15,60,160);
insert into vehicule values(0030,"UtilitaireElectrique",5,150,500);
insert into vehicule values(0040,"UtilitaireElectrique",3,200,700);
insert into vehicule values(0050,"Velo-cargo",3,50,130);
insert into vehicule values(0060,"Triporteur",10,80,100);

insert into livreur VALUES(31,"Dupont","Xavier",'2023/03/05');
insert into livreur VALUES(32,"Trachi","Salma",'2025/07/12');
insert into livreur VALUES(33,"Maury","Amandine",'2024/10/09');
insert into livreur VALUES(34,"Imbart","Tissiana",'2022/02/16');
insert into livreur VALUES(35,"Garnier","François",'2020/04/04');
insert into livreur VALUES(36,"Laurent","Sofia",'2026/01/03');
insert into livreur VALUES(37,"Bureau","Laurent",'2022/05/23');
insert into livreur VALUES(38,"Payet","Eric",'2021/08/09');
insert into livreur VALUES(39,"Ibazizen","Mohamed",'2020/02/28');
insert into livreur VALUES(40,"Diakité","Ibrahima",'2026/02/10');

insert INTO client VALUES(11,"Le fournil du Marais","184 Avenue de La Rochelle","79000", "Niort");
insert INTO client VALUES(12,"DB PAIN","7 Rue des Azalées","79300", "Bressuire");
insert INTO client VALUES(13,"DECATHLON","5 Rue Charles Darwin","79000", "Niort");
insert INTO client VALUES(14,"Epicerie Caucase","21 Bis Rue Laurent Bonnevay","79000", "Niort");
insert INTO client VALUES(15,"Atelier de l'Excellence Echiré","66 Place de l'Eglise","79410", "Echiré");
insert INTO client VALUES(16,"Execo","62 Avenue du Maréchal de Lattre de Tassigny","79000", "Niort");
insert INTO client VALUES(17,"Autodistribution Talbot","191 Avenue Arisitide Briand","79200", "Parthenay");
insert INTO client VALUES(18,"LA clef des champs","Zone Mude","79000", "Bessines");
insert INTO client VALUES(19,"Pharmacie Victor Hugo",";5 Avenue Victor Hugo","79100", "Thouars");
insert INTO client VALUES(20,"Tobacco Europe","7Pl. de l'Europe","17000", "La Rochelle");

INSERT INTO livraison VALUES(1, 15, 3, 1, 31);
INSERT INTO livraison VALUES(2, 25, 3, 2, 32);
INSERT INTO livraison VALUES(3, 3, 3, 3, 36);
INSERT INTO livraison VALUES(4, 12, 6, 4, 35);
INSERT INTO livraison VALUES(5, 21, 1, 5, 40);
INSERT INTO livraison VALUES(6, 10, 2, 6, 32);
INSERT INTO livraison VALUES(7, 9, 4, 7, 34);
INSERT INTO livraison VALUES(8, 15, 1, 8, 38);
INSERT INTO livraison VALUES(9, 13, 2, 9, 35);
INSERT INTO livraison VALUES(10, 23, 4, 10, 39);

INSERT INTO tournee VALUES(1, '2023-04-21', 31, 30);
INSERT INTO tournee VALUES(2, '2025-07-20', 32, 30);
INSERT INTO tournee VALUES(3, '2026-02-10', 36, 60);
INSERT INTO tournee VALUES(4, '2025-04-23', 35, 20);
INSERT INTO tournee VALUES(5, '2026-02-18', 40, 50);
INSERT INTO tournee VALUES(6, '2025-08-03', 32, 50);
INSERT INTO tournee VALUES(7, '2022-03-02', 34, 30);
INSERT INTO tournee VALUES(8, '2022-08-19', 38, 60);
INSERT INTO tournee VALUES(9, '2024-12-10', 35, 40);
INSERT INTO tournee VALUES(10, '2024-03-10', 39, 20);


INSERT INTO appartenir VALUES(8, 1);
INSERT INTO appartenir VALUES(10, 2);
INSERT INTO appartenir VALUES(9, 3);
INSERT INTO appartenir VALUES(6, 4);
INSERT INTO appartenir VALUES(3, 5);
INSERT INTO appartenir VALUES(4, 6);
INSERT INTO appartenir VALUES(5, 7);
INSERT INTO appartenir VALUES(7, 8);
INSERT INTO appartenir VALUES(2, 9);
INSERT INTO appartenir VALUES(1, 10);


INSERT INTO consoco2 VALUES(10, '2025', 4);
INSERT INTO consoco2 VALUES(10, '2026', 3);
INSERT INTO consoco2 VALUES(20, '2025', 9);
INSERT INTO consoco2 VALUES(20, '2026', 7);
INSERT INTO consoco2 VALUES(30, '2025', 21);
INSERT INTO consoco2 VALUES(30, '2026', 18);
INSERT INTO consoco2 VALUES(40, '2025', 21);
INSERT INTO consoco2 VALUES(40, '2026', 18);
INSERT INTO consoco2 VALUES(50, '2025', 4);
INSERT INTO consoco2 VALUES(50, '2026', 3);
INSERT INTO consoco2 VALUES(60, '2025', 9);
INSERT INTO consoco2 VALUES(60, '2026', 7);


INSERT INTO entree VALUES(1, '2022-03-12', 2, 21);
INSERT INTO entree VALUES(2, '2024-02-10', 7, 2);
INSERT INTO entree VALUES(3, '2024-04-20', 3, 3);
INSERT INTO entree VALUES(4, '2025-06-23', 9, 1);
INSERT INTO entree VALUES(5, '2024-09-09', 11, 6);
INSERT INTO entree VALUES(6, '2026-02-08', 4, 9);
INSERT INTO entree VALUES(7, '2025-01-13', 10, 6);
INSERT INTO entree VALUES(8, '2025-08-09', 1, 5);
INSERT INTO entree VALUES(9, '2023-06-12', 6, 9);
INSERT INTO entree VALUES(10, '2023-11-10', 13, 21);

INSERT INTO annee VALUES('2025');
INSERT INTO annee VALUES('2026');